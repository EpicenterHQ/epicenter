/** THROWAWAY browser controller. All provider data is fictional. */
import { openDeviceStorage, type CallOptions } from './device.js';
const device = await openDeviceStorage();
let db: Awaited<ReturnType<typeof device.openSqlite>> | undefined;
let fetches = 0;
const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
function errorInfo(error: unknown) {
  const e = error as Error & { code?: number };
  return { name: e.name, code: e.code ?? null, message: e.message };
}
function summary(latencies: number[], errors: ReturnType<typeof errorInfo>[]) {
  const sorted = [...latencies].sort((a, b) => a - b);
  const quantile = (q: number) => sorted[Math.max(0, Math.ceil(sorted.length * q) - 1)] ?? null;
  return { n: sorted.length, p50: quantile(.5), p95: quantile(.95), max: sorted.at(-1) ?? null,
    over250ms: sorted.filter(ms => ms > 250).length, errors, fetches };
}
const probe = {
  device,
  async open(name = 'messages.sqlite') { db = await device.openSqlite(name); return db.info; },
  async close() { await db?.close(); db = undefined; },
  all: (sql: string, bind: (string | number | null)[] = [], opts?: CallOptions) => db!.all(sql, bind, opts),
  run: (sql: string, bind: (string | number | null)[] = [], waitMs?: number) => db!.run(sql, bind, waitMs),
  batch: (statements: Parameters<NonNullable<typeof db>['batch']>[0], opts?: CallOptions) => db!.batch(statements, opts),
  stall: (ms: number, marker: string) => db!.stall(ms, marker),
  locks: () => navigator.locks.query(),
  async fetchPage(chat: string, page: number) {
    fetches++;
    await sleep(15);
    return { messages: Array.from({ length: 25 }, (_, i) => ({ id: `${chat}:${page * 25 + i}`, chat,
      ts: page * 25 + i, body: `fictional ${chat}:${page * 25 + i}` })), cursor: page + 1 };
  },
  async syncPages(chat: string, fromPage: number, toPage: number) {
    const latencies: number[] = [], errors: ReturnType<typeof errorInfo>[] = [];
    for (let page = fromPage; page < toPage; page++) {
      const fetched = await probe.fetchPage(chat, page);
      const start = performance.now();
      try {
        await db!.batch([...fetched.messages.map(message => ({
          sql: 'INSERT INTO messages(id, chat, ts, body) VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body, ts=excluded.ts',
          bind: [message.id, message.chat, message.ts, message.body],
        })), { sql: 'INSERT INTO sync_state(chat, cursor) VALUES (?,?) ON CONFLICT(chat) DO UPDATE SET cursor=max(cursor,excluded.cursor)', bind: [chat, fetched.cursor] }]);
      } catch (error) { errors.push(errorInfo(error)); }
      latencies.push(performance.now() - start);
    }
    return summary(latencies, errors);
  },
  async readLoop(chat: string, count: number) {
    const latencies: number[] = [], errors: ReturnType<typeof errorInfo>[] = [];
    for (let i = 0; i < count; i++) {
      const start = performance.now();
      try { await db!.all('SELECT id, ts FROM messages WHERE chat=? ORDER BY ts DESC LIMIT 50', [chat]); }
      catch (error) { errors.push(errorInfo(error)); }
      latencies.push(performance.now() - start);
    }
    return summary(latencies, errors);
  },
  getFetches: () => fetches,
};
declare global { var deviceProbe: typeof probe; }
globalThis.deviceProbe = probe;
document.body.innerHTML = '<h1>Disposable OPFS coordination probe</h1><p>Fictional data only. Use deviceProbe in the console.</p>';
