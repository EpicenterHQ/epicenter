/** THROWAWAY evidence harness. Run: bun run.ts [--manual]. No real user data. */
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { chromium, firefox, webkit, type Page } from 'playwright';
import type {} from './client.js';

const scripts = new Map<string, string>();
for (const entry of ['client', 'sqlite-worker']) {
  const build = await Bun.build({ entrypoints: [join(import.meta.dir, entry + '.ts')], target: 'browser', external: ['@sqlite.org/sqlite-wasm'] });
  if (!build.success) throw new AggregateError(build.logs, 'Build failed');
  scripts.set('/' + entry + '.js', (await build.outputs[0]!.text()).replaceAll('@sqlite.org/sqlite-wasm', '/vendor/index.mjs'));
}
const headers = {
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Embedder-Policy': 'require-corp',
  'Cache-Control': 'no-store',
};
const html = '<!doctype html><title>Device OPFS prototype</title><body><script type="module" src="/client.js"></script>';
const server = Bun.serve({
  hostname: '127.0.0.1', port: 0,
  fetch(request) {
    const path = new URL(request.url).pathname;
    const isolated = !path.startsWith('/without-headers');
    const common = isolated ? headers : { 'Cache-Control': 'no-store' };
    if (scripts.has(path)) return new Response(scripts.get(path), { headers: { ...common, 'Content-Type': 'text/javascript' } });
    if (path.startsWith('/vendor/') && !path.includes('..')) {
      const file = Bun.file(join(import.meta.dir, 'node_modules/@sqlite.org/sqlite-wasm/dist', path.slice(8)));
      return new Response(file, { headers: { ...common, 'Content-Type': path.endsWith('.wasm') ? 'application/wasm' : 'text/javascript' } });
    }
    return new Response(html, { headers: { ...common, 'Content-Type': 'text/html' } });
  },
});
if (Bun.argv.includes('--manual')) {
  console.log('Prototype server: ' + probeUrl('weblock-asap', 'PROTOTYPE-wipe-me-manual').href);
  console.log('Use deviceProbe in the browser console; fictional data only.');
  await new Promise(() => {});
}
const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
function check(value: unknown, message: string): asserts value {
  if (!value) throw new Error(message);
}
async function result(page: Page, expression: string) {
  return page.evaluate(async expression => {
    const start = performance.now();
    try {
      const value: unknown = await (0, eval)(expression);
      return { ok: true, value, ms: performance.now() - start };
    }
    catch (error) {
      const e = error as Error & { code?: number; dispatched?: boolean };
      return { ok: false, name: e.name, code: e.code ?? null, message: e.message, dispatched: e.dispatched, ms: performance.now() - start };
    }
  }, expression);
}
// Measure after awaiting the reply, including worker lane and SQL lock acquisition.
async function timed(page: Page, expression: string) {
  const start = performance.now();
  const outcome = await result(page, expression);
  return { ...outcome, ms: performance.now() - start };
}
function probeUrl(candidate: string, root: string) {
  const url = new URL(server.url);
  url.search = new URLSearchParams({ root, vfs: 'opfs', sql: candidate === 'none' ? 'none' : 'weblock', asap: candidate === 'weblock-asap' ? '1' : '0' }).toString();
  return url;
}
async function ready(page: Page, candidate: string, root: string) {
  page.setDefaultTimeout(30_000);
  await page.goto(probeUrl(candidate, root).href);
  await page.waitForFunction(() => !!globalThis.deviceProbe);
}
function statements(page: number) {
  return [...Array.from({ length: 25 }, (_, i) => ({
    sql: 'INSERT INTO messages(id,chat,ts,body) VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,ts=excluded.ts',
    bind: [`chat-1:${page * 25 + i}`, 'chat-1', page * 25 + i, `fictional chat-1:${page * 25 + i}`],
  })), { sql: 'INSERT INTO sync_state(chat,cursor) VALUES (?,?) ON CONFLICT(chat) DO UPDATE SET cursor=max(cursor,excluded.cursor)', bind: ['chat-1', page + 1] }];
}
const batchExpression = (page: number, acquireMs?: number) => `deviceProbe.batch(${JSON.stringify(statements(page))},${JSON.stringify({ acquireMs })})`;
async function scalar(page: Page, sql: string): Promise<number | string> {
  return page.evaluate(async sql => {
    const rows = await deviceProbe.all(sql) as Record<string, number | string>[];
    return Object.values(rows[0]!)[0]!;
  }, sql);
}
async function lockSnapshot(page: Page) {
  return page.evaluate(async () => {
    const locks = await deviceProbe.locks();
    const compact = (items: LockInfo[] | undefined) => items?.map(({ name, mode }) => ({ name, mode }));
    return { held: compact(locks.held), pending: compact(locks.pending) };
  });
}
async function integrity(page: Page) {
  const value = await scalar(page, 'PRAGMA integrity_check');
  check(value === 'ok', 'integrity_check failed: ' + value);
  return value;
}
const candidates = ['none', 'weblock', 'weblock-asap'].filter(name => !Bun.argv.some(arg => arg.startsWith('--candidate=')) || Bun.argv.includes('--candidate=' + name));
const engines = Object.entries({ chromium, firefox, webkit }).filter(([name]) => !Bun.argv.some(arg => arg.startsWith('--engine=')) || Bun.argv.includes('--engine=' + name));
check(candidates.length && engines.length, 'Unknown candidate or engine filter');
const evidence: { candidate: string; engine: string; cases: { name: string; value: unknown }[]; error?: string }[] = [];
const runId = new Date().toISOString().replaceAll(':', '-');
const output = join(import.meta.dir, '../results/run-' + runId + '.json');
check(!(await Bun.file(output).exists()), 'Refusing to overwrite results');
try {
  for (const candidate of candidates) for (const [engine, browserType] of engines) {
    const root = `PROTOTYPE-wipe-me-${runId}-${candidate}-${engine}`.replace(/[^A-Za-z0-9-]/g, '-');
    const profile = await mkdtemp(join(tmpdir(), 'PROTOTYPE-wipe-me-' + candidate + '-' + engine + '-'));
    const report: (typeof evidence)[number] = { candidate, engine, cases: [] };
    evidence.push(report);
    let context: Awaited<ReturnType<typeof chromium.launchPersistentContext>> | undefined;
    const record = (name: string, value: unknown) => {
      report.cases.push({ name, value });
      console.log(JSON.stringify({ candidate, engine, name, value }));
    };
    try {
      context = await browserType.launchPersistentContext(profile, { headless: true });
      let a = await context.newPage();
      const b = await context.newPage();
      await ready(a, candidate, root);
      await ready(b, candidate, root);
      const opened = await a.evaluate(() => deviceProbe.open('messages.sqlite'));
      await a.evaluate(() => deviceProbe.run('CREATE TABLE messages(id TEXT PRIMARY KEY,chat TEXT NOT NULL,ts INTEGER NOT NULL,body TEXT NOT NULL); CREATE TABLE sync_state(chat TEXT PRIMARY KEY,cursor INTEGER NOT NULL); CREATE TABLE probe_marks(marker TEXT);'));
      await b.evaluate(() => deviceProbe.open('messages.sqlite'));
      const environment = await a.evaluate(() => ({ isolated: crossOriginIsolated, userAgent: navigator.userAgent }));
      const files = await a.evaluate(() => deviceProbe.device.files.list());
      check(files.includes('messages.sqlite') && !files.some(name => name.includes('?')), 'URI did not resolve to plain filename');
      record('environment', { root, version: context.browser()?.version(), ...environment, open: opened, files });

      const syncStart = performance.now();
      const [aSync, bSync, aRead, bRead] = await Promise.all([
        a.evaluate(() => deviceProbe.syncPages('chat-1', 0, 20)),
        b.evaluate(() => deviceProbe.syncPages('chat-1', 10, 30)),
        a.evaluate(() => deviceProbe.readLoop('chat-1', 40)),
        b.evaluate(() => deviceProbe.readLoop('chat-1', 40)),
      ]);
      const totals = { messages: await scalar(b, 'SELECT count(*) FROM messages'), distinct: await scalar(b, 'SELECT count(DISTINCT id) FROM messages'), cursor: await scalar(b, "SELECT cursor FROM sync_state WHERE chat='chat-1'") };
      const fetches = { A: await a.evaluate(() => deviceProbe.getFetches()), B: await b.evaluate(() => deviceProbe.getFetches()) };
      record('concurrent-sync', { complete: totals.messages === 750 && totals.cursor === 30, totals, fetches, aSync, bSync, aRead, bRead, wallMs: performance.now() - syncStart, integrity: await integrity(b) });
      check(totals.distinct === totals.messages, 'Concurrent sync has duplicate ids');
      check(Number(totals.messages) % 25 === 0, 'Concurrent sync has a partial page');
      if (totals.messages !== 750) check(aSync.errors.length + bSync.errors.length > 0, 'Incomplete sync without reported errors');
      check(fetches.A === 20 && fetches.B === 20, 'Unexpected fictional fetch count');

      await b.evaluate(() => deviceProbe.close());
      const reopened = await b.evaluate(() => deviceProbe.open('messages.sqlite'));
      record('peer-open-then-batch', { reopened, batch: await timed(a, batchExpression(0)) });

      const before = { count: await scalar(b, 'SELECT count(*) FROM messages'), cursor: await scalar(b, "SELECT cursor FROM sync_state WHERE chat='chat-1'") };
      const failed = await timed(b, `deviceProbe.batch(${JSON.stringify([
        { sql: "INSERT INTO messages VALUES ('rollback-only','chat-1',999,'fictional rollback')" },
        { sql: "UPDATE sync_state SET cursor=999 WHERE chat='chat-1'" },
        { sql: "INSERT INTO messages VALUES ('invalid','chat-1',1000,NULL)" },
      ])})`);
      const after = { count: await scalar(b, 'SELECT count(*) FROM messages'), cursor: await scalar(b, "SELECT cursor FROM sync_state WHERE chat='chat-1'") };
      check(!failed.ok && JSON.stringify(before) === JSON.stringify(after), 'Failed batch did not roll back');
      check(await scalar(b, "SELECT count(*) FROM messages WHERE id='rollback-only'") === 0, 'Rolled back message survived');
      record('failed-batch-rolls-back', { failed, before, after });

      const held = timed(a, "deviceProbe.stall(6000,'A-held')");
      await sleep(300);
      const locks = await lockSnapshot(b);
      const pendingBatch = timed(b, batchExpression(40, 1000));
      const pendingRead = timed(b, "deviceProbe.all('SELECT count(*) n FROM messages',[],{acquireMs:1000})");
      const failFast = timed(b, "deviceProbe.all('SELECT 1 x',[],{acquireMs:0})");
      const atDeadline = await Promise.race([
        pendingBatch.then(outcome => ({ settledBefore1500ms: true, outcome })),
        sleep(1500).then(() => ({ settledBefore1500ms: false, callerOutcome: 'caller reply timeout at 1500ms; request still pending' })),
      ]);
      const [batchOutcome, readOutcome, holdOutcome, failFastOutcome] = await Promise.all([pendingBatch, pendingRead, held, failFast]);
      const page40Count = await scalar(b, "SELECT count(*) FROM messages WHERE chat='chat-1' AND ts>=1000 AND ts<1025");
      const retry = await timed(b, batchExpression(40));
      record('held-peer', { locks, atDeadline, batchOutcome, readOutcome, failFast: failFastOutcome, holdOutcome, page40CountBeforeRetry: page40Count, retry });
      if (candidate !== 'none') {
        for (const [name, outcome] of Object.entries({ batchOutcome, readOutcome, failFastOutcome })) {
          check(outcome.ok === false && outcome.name === 'DatabaseBusy' && outcome.dispatched === false, name + ' must refuse before dispatch');
        }
        check(page40Count === 0, 'Page 40 appeared before retry');
      }
      check(retry.ok && await scalar(b, 'SELECT count(*) FROM messages WHERE ts>=1000 AND ts<1025') === 25, 'Page 40 retry failed');

      const dying = timed(a, "deviceProbe.stall(8000,'A-died')").catch(error => ({ pageClosed: String(error) }));
      await sleep(500);
      const waiting = timed(b, batchExpression(41, 10000));
      await sleep(500);
      const closeStart = performance.now();
      await a.close();
      const ownerOutcome = await waiting;
      const msFromCloseToSettle = performance.now() - closeStart;
      const diedMarks = await scalar(b, "SELECT count(*) FROM probe_marks WHERE marker='A-died'");
      const page41Count = await scalar(b, 'SELECT count(*) FROM messages WHERE ts>=1025 AND ts<1050');
      record('owner-disappears', { outcome: ownerOutcome, msFromCloseToSettle, dying: await dying, diedMarks, page41Count, integrity: await integrity(b) });
      check(ownerOutcome.ok && diedMarks === 0 && page41Count === 25, 'Owner disappearance recovery incorrect');

      a = await context.newPage();
      await ready(a, candidate, root);
      await a.evaluate(() => deviceProbe.open('messages.sqlite'));
      const liveLocks = await lockSnapshot(a);
      // Capture the short-lived SQL lock during an active request, alongside both raw leases.
      const snapshotHold = timed(b, "deviceProbe.stall(500,'snapshot')");
      await sleep(100);
      const activeLocks = await lockSnapshot(a);
      await snapshotHold;
      const rawBusy = await result(a, 'deviceProbe.device.files.read("messages.sqlite").then(bytes=>bytes.length)');
      check(!rawBusy.ok && rawBusy.name === 'FileBusy', 'Raw read ignored connection lease');
      const expectedCount = await scalar(b, 'SELECT count(*) FROM messages');
      await a.evaluate(() => deviceProbe.close());
      await b.evaluate(() => deviceProbe.close());
      const copied = await a.evaluate(async () => {
        const bytes = await deviceProbe.device.files.read('messages.sqlite');
        const header = new TextDecoder().decode(bytes.slice(0, 16));
        await deviceProbe.device.files.write('copy.sqlite', bytes);
        await deviceProbe.open('copy.sqlite');
        const count = await deviceProbe.all('SELECT count(*) n FROM messages');
        return { header, bytes: bytes.length, count };
      });
      check(copied.header === 'SQLite format 3\0', 'Incorrect SQLite file header');
      check((copied.count as { n: number }[])[0]!.n === expectedCount, 'Copied file count mismatch');
      record('raw-access-composition', { liveLocks, activeLocks, rawBusy, expectedCount, copied });
      await a.evaluate(() => deviceProbe.close());
    } catch (error) {
      report.error = String(error);
      console.error(candidate + '/' + engine + ': ' + error);
    } finally {
      await context?.close();
      await rm(profile, { recursive: true, force: true });
    }
  }
} finally {
  server.stop(true);
  await Bun.write(output, JSON.stringify({ package: '@sqlite.org/sqlite-wasm@3.54.1-build1', playwright: '1.61.1', platform: { os: process.platform, arch: process.arch, bun: Bun.version }, candidates, engines: engines.map(([name]) => name), vfs: 'opfs', evidence }, null, 2));
  console.log('Results: ' + output);
}
if (evidence.some(report => report.error)) process.exitCode = 1;
