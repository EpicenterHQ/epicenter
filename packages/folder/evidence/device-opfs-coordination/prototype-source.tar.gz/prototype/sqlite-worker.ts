/** THROWAWAY: one official OPFS connection; fictional data only. */
import sqlite3InitModule, { type Database, type SqlValue } from '@sqlite.org/sqlite-wasm';

const scope = globalThis as unknown as DedicatedWorkerGlobalScope;
const loading = sqlite3InitModule();
let db: Database | undefined;
let retries = 0;

async function attempt<T>(operation: () => T, waitMs: number): Promise<T> {
  const until = performance.now() + waitMs;
  for (;;) {
    try { return operation(); }
    catch (error) {
      const code = (error as { resultCode?: number }).resultCode;
      if ((code !== 5 && code !== 6) || performance.now() >= until) throw error;
      retries++;
      await new Promise(resolve => setTimeout(resolve, 5));
    }
  }
}

type Command = {
  id: number;
  action: string;
  path?: string;
  asap?: boolean;
  ms?: number;
  marker?: string;
  sql?: string;
  bind?: SqlValue[];
  statements?: { sql: string; bind?: SqlValue[] }[];
  waitMs?: number;
};
let lane = Promise.resolve();
scope.onmessage = ({ data }: MessageEvent<Command>) => {
  lane = lane.then(async () => {
    const before = retries;
    try {
      const sqlite = await loading;
      const value = await attempt(() => {
        if (data.action === 'open') {
          const Db = new URL(scope.location.href).searchParams.get('vfs') === 'opfs-wl'
            ? sqlite.oo1.OpfsWlDb : sqlite.oo1.OpfsDb;
          if (!Db) throw new Error('Official opfs VFS unavailable');
          db = new Db(data.asap ? `file:${data.path}?opfs-unlock-asap=1` : data.path!, 'c');
          sqlite.capi.sqlite3_busy_timeout(db, 50);
          return { version: sqlite.version.libVersion, filename: db.filename };
        }
        if (!db) throw new Error('No connection');
        if (data.action === 'close') {
          db.close();
          db = undefined;
          return null;
        }
        if (data.action === 'all') return db.selectObjects(data.sql!, data.bind);
        if (data.action === 'stall') {
          // PROBE-ONLY FAULT GATE: models one long-running request (pathological SQL / slow device). Not an API.
          db.exec('BEGIN IMMEDIATE');
          db.exec({ sql: 'INSERT INTO probe_marks(marker) VALUES (?)', bind: [data.marker!] });
          const start = performance.now();
          while (performance.now() < start + data.ms!) { /* synchronous worker stall */ }
          db.exec('COMMIT');
          return null;
        }
        if (data.action === 'batch') {
          db.exec('BEGIN IMMEDIATE');
          const changes: number[] = [];
          try {
            for (const statement of data.statements!) {
              db.exec({ sql: statement.sql, bind: statement.bind });
              changes.push(Number(db.changes()));
            }
            db.exec('COMMIT');
          } catch (error) { db.exec('ROLLBACK'); throw error; }
          return { changes };
        }
        db.exec({ sql: data.sql!, bind: data.bind });
        return { changes: db.changes() };
      }, data.waitMs ?? 5000);
      scope.postMessage({ id: data.id, value, retries: retries - before });
    } catch (error) {
      scope.postMessage({
        id: data.id,
        error: { name: (error as Error).name, message: (error as Error).message, code: (error as { resultCode?: number }).resultCode },
        retries: retries - before,
      });
    }
  });
};
