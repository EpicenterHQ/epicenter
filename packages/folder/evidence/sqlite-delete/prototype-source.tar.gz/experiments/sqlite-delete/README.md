# SQLite deletion interruption prototype

This throwaway experiment tests one question: can main-first deletion, orphan refusal, and explicit cleanup retry work without a database catalog or tombstone? All database contents, reserved companion fixtures, browser profiles, and directories are fictional. Nothing connects to Beeper or any provider. No production package, app, or ADR was changed.

From this directory, run:

```sh
bun run run.ts
```

The runner builds the native host offline with `/opt/homebrew/bin/cargo`, serves a loopback-only browser fixture with COOP/COEP isolation headers, and tests Chromium, Firefox, and Playwright WebKit. It uses the copied baseline dependencies already in `baseline-browser/node_modules` and installed Playwright browsers. There is no install step and no need to bundle Bun in a desktop app: Bun is only the experiment driver. Use `--native-only` or `--browser-only` for a subset.

Machine-readable output goes to `results/<timestamp>/evidence.json`; `results/latest.json` points to the last run, including failed runs. Disposable browser profiles live under task-specific temporary paths and are removed in `finally`. Native fixture files remain under the corresponding results directory for inspection. The host refuses roots outside this experiment's `results/` directory.

The first complete passing matrix is `results/2026-10-22T07-40-04.920Z/evidence.json`: 33 named native checks and 30 per browser, 123 named checks total. The actual SQLite versions queried were native 3.53.2 and browser 3.54.1. Chromium was 149.0.7827.55, Firefox 151.0, and Playwright WebKit reported Safari 26.5. Earlier failed runs expose two corrected harness issues: stale checkpoint selection and a missing await while seeding a browser directory fixture. These were harness failures, not claimed successful deletion evidence.

## Candidate API

Both facades retain one connection per opened handle:

```ts
const db = await device.sqlite.open('fictional.sqlite');
await db.run('CREATE TABLE messages (text TEXT)');
await db.batch([
  { sql: 'INSERT INTO messages VALUES (?)', params: ['Fictional hello'] },
]);
await db.all('SELECT text FROM messages');
await db.close(); // Repeated facade calls await the same promise.
// await db[Symbol.asyncDispose]() calls the same close operation.
await device.sqlite.delete('fictional.sqlite');
```

`native/client.ts` supplies the TypeScript facade over a native Rust/rusqlite JSON-lines host. `browser/client.ts` supplies the facade over dedicated workers. `browser/worker.ts` uses the official transparent OPFS VFS (`sqlite.oo1.OpfsDb`), with literal files below the fictional OPFS directory `fictional-sqlite-delete`. It does not use SAH-pool filename mappings.

Only a single relative filename is admitted in this experiment. Nested paths, real app scoping, AppData selection, Tauri IPC/window integration, and parent device retirement are outside it. Extra operation options such as `pauseAt`, `delayMs`, `failInspect`, and `failRemove`, plus raw fixture/reset/interrupt methods, are private harness instrumentation, not proposed public API.

## What deletion does

For `p`, only `p`, `p-journal`, `p-wal`, and `p-shm` are considered. Remove the main file first; on a main inspection/removal failure stop before touching companions. Then attempt every exact companion despite individual failures. Treat only NotFound as absence. Inspect file kind first so even an empty directory is preserved; never recurse in the deletion implementation. Verify the whole family absent before reporting success. Failures carry affected paths and attempted removals. A companion failure can be reported both at the failed removal and at final verification.

Opening refuses to create a new main beside any exact orphaned companion. Inspection errors do not count as absence. After main removal, leftovers are a discoverable cleanup state; retrying deletion with no main continues cleanup. Before the first unlink, interruption leaves the original main bytes untouched and cannot encode a durable deletion request. The app must persist that intent separately when needed.

Admission tracking is shared across managed handles in one native host process or one browser tab. Opening, live, and closing native connections remain Busy until physical connection release. Browser close awaits `db.close()` acknowledgment before releasing its count. If a database or deletion worker is terminated without acknowledgment, this prototype conservatively retains Busy until the page is retired; it does not pretend `Worker.terminate()` is a resource-release join. New pages can retry after the interrupted worker is gone in the tested boundary cases. Other processes/tabs/raw clients remain the caller's quiescence responsibility.

## Evidence covered

- Actual native SIGKILL and browser deletion-worker termination before main removal and after each of the four exact removal steps. Restart with a new native host or browser page; assert the exact surviving family, refuse orphan opens, retry twice, and create an empty replacement only after cleanup.
- A cleanup retry interrupted again, followed by two repeated injected companion unlink failures, then successful cleanup.
- Main and every companion inspection/unlink failure. Main failure preserves all companions. Companion failure still removes subsequent family members. Inspection failures are reported rather than interpreted as absence.
- Empty and nonempty directories at every family path are preserved. Neighbor bytes remain `KEEP`; suffix lookalikes such as `p-wal.backup` remain unchanged.
- Tracked opening/live/closing connections refuse deletion; an admitted deletion refuses another delete and an open, including across browser device handles in the same tab. Repeated close and asynchronous disposal use the persistent handle cleanup.
- Constraint failure rolls back the whole atomic SQL batch on native and every browser engine.
- Separately, real SQLite-created native WAL and rollback-journal remnants survive SIGKILL and are removed successfully. These are distinct from the deliberately synthetic all-companion boundary fixtures.
- Each browser closes and reopens its task-owned persistent profile, reads committed fictional data, and deletes it successfully. A crashed database worker remains tracked Busy until page retirement.

## Limits

The native executable tests the Rust storage core and process-local registry, not Tauri invocation, renderer/window cleanup, or installed-app updates. Browser interruptions terminate a dedicated worker at acknowledged filesystem boundaries, not a whole browser process or machine. Profile restart is orderly. No claim covers power loss, directory fsync ordering, an interruption *inside* one pending unlink, secure erasure, provider-side deletion, or exclusion of uncooperative clients. A synthetic family containing all three companions is not claimed to be a naturally occurring SQLite state or evidence of stale-WAL replay.

The SQL harness intentionally checks basic persistence, lifetime, and atomic rollback. It is not a replacement for the earlier full SQL/value/authorizer parity suite. In particular it does not reimplement every production-facing SQL restriction or safety limit. No result promotes this prototype into a package or resolves the remaining integration work.

Static check used:

```sh
bun baseline-browser/node_modules/typescript/lib/tsc.js --noEmit \
  --target ESNext --module ESNext --moduleResolution Bundler \
  --lib ESNext,DOM,DOM.Iterable,DOM.AsyncIterable,WebWorker \
  --types bun --typeRoots ./baseline-browser/node_modules/@types \
  --skipLibCheck --strict \
  browser/client.ts browser/worker.ts native/client.ts run.ts
```

Rust formatting is checked with `cargo fmt --manifest-path native/Cargo.toml --check`.
