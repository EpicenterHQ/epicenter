/** Throwaway worker executor. Only a task-owned fictional OPFS directory. */
import sqlite3InitModule from '@sqlite.org/sqlite-wasm';
const family = ['', '-journal', '-wal', '-shm'];
let db: any;
let loading: Promise<any> | undefined;
let lane = Promise.resolve();
const root = () => navigator.storage.getDirectory().then(d => d.getDirectoryHandle('fictional-sqlite-delete', { create: true }));
const fault = (options: any, key: string, path: string) => options?.[key]?.includes(path);
const coded = (code: string, message: string, extra = {}) => Object.assign(new Error(message), { code, ...extra });
async function exists(dir: FileSystemDirectoryHandle, path: string, options: any) {
  if (fault(options, 'failInspect', path)) throw coded('Inspect', 'Injected inspection failure: ' + path);
  try { const file = await dir.getFileHandle(path); if (file.kind !== 'file') throw coded('NotFile', path); return true; }
  catch (error) { if ((error as Error).name === 'NotFoundError') return false; throw error; }
}
async function checkpoint(id: number, step: string, options: any) {
  postMessage({ event: 'checkpoint', id, step });
  if (options?.pauseAt === step) await new Promise(() => {});
}
async function execute(data: any) {
  const dir = await root(); const { op, path, options = {}, id } = data;
  if (op === 'delete') {
    const failures: any[] = [], attempted: string[] = [];
    await checkpoint(id, 'before-main', options);
    for (let i = 0; i < family.length; i++) {
      const file = path + family[i];
      try {
        if (await exists(dir, file, options)) {
          if (fault(options, 'failRemove', file)) throw coded('Remove', 'Injected unlink failure: ' + file);
          await dir.removeEntry(file); // No recursive option; kind inspection also preserves empty dirs.
        }
        attempted.push(file);
      } catch (error) {
        failures.push({ path: file, error: { code: (error as any).code ?? (error as Error).name, message: (error as Error).message } });
        if (!i) throw coded('DeleteFailed', 'Main removal failed', { failures, attempted });
      }
      await checkpoint(id, ['after-main', 'after-journal', 'after-wal', 'after-shm'][i], options);
    }
    for (const suffix of family) {
      const file = path + suffix;
      try { if (await exists(dir, file, options)) failures.push({ path: file, error: { code: 'Remaining' } }); }
      catch (error) { failures.push({ path: file, error: { code: (error as any).code ?? (error as Error).name } }); }
    }
    if (failures.length) throw coded('DeleteFailed', 'Family cleanup incomplete', { failures, attempted });
    return { absent: true, attempted };
  }
  if (op === 'open') {
    if (options.delayMs) await new Promise(resolve => setTimeout(resolve, options.delayMs));
    if (!await exists(dir, path, options)) {
      for (const suffix of family.slice(1)) if (await exists(dir, path + suffix, options)) throw coded('OrphanedCompanions', path);
    }
    loading ??= sqlite3InitModule();
    const sqlite = await loading;
    db = new sqlite.oo1.OpfsDb('/fictional-sqlite-delete/' + path, 'c');
    return { version: sqlite.version.libVersion, filename: db.filename };
  }
  if (!db) throw coded('Closed', 'No connection');
  if (op === 'close') { if (options.delayMs) await new Promise(resolve => setTimeout(resolve, options.delayMs)); db.close(); db = undefined; return null; }
  if (op === 'all') return db.selectObjects(data.sql, data.params);
  if (op === 'run' || op === 'batch') {
    const statements = op === 'run' ? [{ sql: data.sql, params: data.params }] : data.statements;
    db.exec('BEGIN IMMEDIATE');
    const changes = [];
    try {
      for (const statement of statements) { db.exec({ sql: statement.sql, bind: statement.params }); changes.push(db.changes()); }
      db.exec('COMMIT');
    } catch (error) { db.exec('ROLLBACK'); throw error; }
    return { changes: op === 'run' ? changes[0] : changes };
  }
  throw coded('Operation', op);
}
onmessage = ({ data }) => { lane = lane.then(async () => {
  try { postMessage({ id: data.id, ok: true, value: await execute(data) }); }
  catch (error) { postMessage({ id: data.id, ok: false, error: { code: (error as any).code ?? (error as Error).name, message: (error as Error).message, failures: (error as any).failures, attempted: (error as any).attempted } }); }
}); };
