/** Throwaway facade. Tracking is this tab only, not a cross-tab maintenance lock. */
const states = new Map<string, { live: number; deleting: boolean }>();
const executors = new Set<Rpc>();
let nextId = 0;
const checkpoints: any[] = [];
const coded = (code: string) => Object.assign(new Error(code), { code });
function filename(path: string) { if (!path || ['.', '..'].includes(path) || /[/\\\0]/.test(path)) throw coded('Path'); return path; }
function state(path: string) { let value = states.get(path); if (!value) states.set(path, value = { live: 0, deleting: false }); return value; }
class Rpc {
  worker = new Worker('/worker.js', { type: 'module' });
  pending = new Map<number, { resolve: (v: any) => void; reject: (e: any) => void }>();
  dead = false;
  constructor() {
    executors.add(this);
    this.worker.onmessage = ({ data }) => {
      if (data.event) { checkpoints.push(data); return; }
      const request = this.pending.get(data.id); if (!request) return;
      this.pending.delete(data.id);
      data.ok ? request.resolve(data.value) : request.reject(Object.assign(new Error(data.error.message), data.error));
    };
    this.worker.onerror = () => this.terminate();
  }
  call(data: any) {
    if (this.dead) return Promise.reject(coded('Closed'));
    const id = ++nextId;
    return new Promise<any>((resolve, reject) => { this.pending.set(id, { resolve, reject }); this.worker.postMessage({ ...data, id }); });
  }
  terminate() { if (this.dead) return; this.dead = true; this.worker.terminate(); executors.delete(this); for (const pending of this.pending.values()) pending.reject(coded('Interrupted')); this.pending.clear(); }
}
function createDevice() {
  const sqlite = {
    async open(path: string, options = {}) {
      filename(path); const entry = state(path); if (entry.deleting) throw coded('Busy'); entry.live++;
      const rpc = new Rpc();
      try {
        await rpc.call({ op: 'open', path, options });
        let closing: Promise<void> | undefined;
        const call = (data: any) => closing ? Promise.reject(coded('Closed')) : rpc.call(data);
        const db = {
          all: (sql: string, params: any[] = []) => call({ op: 'all', sql, params }),
          run: (sql: string, params: any[] = []) => call({ op: 'run', sql, params }),
          batch: (statements: any[]) => call({ op: 'batch', statements }),
          close(options = {}) {
            return closing ??= rpc.call({ op: 'close', options }).then(() => { rpc.terminate(); entry.live--; }); // A failed/terminated close retains Busy until this tab retires.
          },
          [Symbol.asyncDispose]() { return this.close(); },
        };
        return db;
      } catch (error) { rpc.terminate(); if (!['Interrupted', 'Closed'].includes((error as any).code)) entry.live--; throw error; }
    },
    async delete(path: string, options = {}) {
      filename(path); const entry = state(path); if (entry.live || entry.deleting) throw coded('Busy'); entry.deleting = true;
      const rpc = new Rpc();
      let acknowledged = false;
      try { const result = await rpc.call({ op: 'delete', path, options }); acknowledged = true; return result; }
      catch (error) { acknowledged = !['Interrupted', 'Closed'].includes((error as any).code); throw error; }
      finally { rpc.terminate(); if (acknowledged) entry.deleting = false; } // A crashed executor retains Busy until tab retirement.
    },
  };
  return { sqlite }; // Parent device lifetime is outside this deletion experiment.
}
const root = () => navigator.storage.getDirectory().then(d => d.getDirectoryHandle('fictional-sqlite-delete', { create: true }));
const probe = {
  device: createDevice(), createDevice, checkpoints,
  async seed(path: string) {
    const dir = await root();
    for (const suffix of ['', '-journal', '-wal', '-shm']) {
      const file = await dir.getFileHandle(path + suffix, { create: true });
      const write = await file.createWritable(); await write.write('fictional-reserved-family-fixture' + suffix); await write.close();
    }
    const file = await dir.getFileHandle(path + '.neighbor', { create: true }); const write = await file.createWritable(); await write.write('KEEP'); await write.close();
  },
  async write(path: string, text: string) { const file=await (await root()).getFileHandle(path,{create:true}); const w=await file.createWritable(); await w.write(text); await w.close(); },
  async files() { const dir = await root(); const names: string[] = []; for await (const [name] of (dir as any).entries()) names.push(name); return names.sort(); },
  async mkdir(path: string, content = false) { const dir = await (await root()).getDirectoryHandle(path, { create: true }); if (content) { const f = await dir.getFileHandle('keep', { create: true }); const w = await f.createWritable(); await w.write('KEEP'); await w.close(); } },
  async remove(path: string) { await (await root()).removeEntry(path, { recursive: true }); },
  async bytes(path: string) { const handle = await (await root()).getFileHandle(path); const file = await handle.getFile(); const buffer = await file.arrayBuffer(); return Array.from(new Uint8Array(buffer as ArrayBuffer)); },
  async reset() { for (const rpc of [...executors]) rpc.terminate(); states.clear(); checkpoints.length = 0; const dir = await root(); for await (const [name] of (dir as any).entries()) await dir.removeEntry(name, { recursive: true }); },
  interrupt() { for (const rpc of [...executors]) rpc.terminate(); },
};
(globalThis as any).probe = probe;
