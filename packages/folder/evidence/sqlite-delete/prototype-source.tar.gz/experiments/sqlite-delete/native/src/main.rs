// Throwaway native host: fictional fixtures only. No Tauri integration claim.
use rusqlite::{
    params_from_iter,
    types::{Value as SqlValue, ValueRef},
    Connection,
};
use serde_json::{json, Value};
use std::{
    collections::HashMap,
    fs,
    io::{self, BufRead, Write},
    path::{Path, PathBuf},
    sync::{Arc, Mutex},
    thread,
    time::Duration,
};
type Conn = Arc<Mutex<Option<Connection>>>;
#[derive(Default)]
struct Registry {
    live: HashMap<String, usize>,
    deleting: HashMap<String, bool>,
    handles: HashMap<String, (String, Conn)>,
}
#[derive(Clone)]
struct Host {
    root: PathBuf,
    state: Arc<Mutex<Registry>>,
    output: Arc<Mutex<()>>,
}
const SUFFIXES: [&str; 4] = ["", "-journal", "-wal", "-shm"];
fn err(code: &str, detail: impl Into<String>) -> Value {
    json!({"code":code,"message":detail.into()})
}
fn emit(h: &Host, v: Value) {
    let _g = h.output.lock().unwrap();
    println!("{}", v);
    io::stdout().flush().unwrap();
}
fn name(v: &Value) -> Result<String, Value> {
    let n = v["path"].as_str().ok_or(err("Path", "Missing path"))?;
    if n.is_empty() || n == "." || n == ".." || n.contains(['/', '\\', '\0']) {
        return Err(err(
            "Path",
            "Only a literal filename is admitted in this prototype",
        ));
    }
    Ok(n.into())
}
fn inspect(p: &Path) -> Result<bool, Value> {
    match fs::symlink_metadata(p) {
        Ok(m) if m.is_file() => Ok(true),
        Ok(_) => Err(err("NotFile", p.display().to_string())),
        Err(e) if e.kind() == io::ErrorKind::NotFound => Ok(false),
        Err(e) => Err(err("Inspect", format!("{}: {e}", p.display()))),
    }
}
fn fault(v: &Value, key: &str, n: &str) -> bool {
    v[key]
        .as_array()
        .map(|a| a.iter().any(|s| s == n))
        .unwrap_or(false)
}
fn checked_inspect(h: &Host, v: &Value, n: &str) -> Result<bool, Value> {
    if fault(v, "failInspect", n) {
        Err(err("Inspect", format!("Injected inspection failure: {n}")))
    } else {
        inspect(&h.root.join(n))
    }
}
fn checkpoint(h: &Host, v: &Value, step: &str) {
    emit(h, json!({"event":"checkpoint","id":v["id"],"step":step}));
    if v["pauseAt"] == step {
        loop {
            thread::park();
        }
    }
}
fn delay(v: &Value) {
    if let Some(ms) = v["delayMs"].as_u64() {
        thread::sleep(Duration::from_millis(ms));
    }
}
fn operation(h: &Host, v: &Value) -> Result<Value, Value> {
    let op = v["op"].as_str().unwrap_or("");
    if op == "open" {
        let n = name(v)?;
        {
            let mut s = h.state.lock().unwrap();
            if s.deleting.contains_key(&n) {
                return Err(err("Busy", "Deletion admitted"));
            }
            *s.live.entry(n.clone()).or_default() += 1;
        }
        emit(h, json!({"event":"opening","id":v["id"]}));
        delay(v);
        let opened = (|| {
            let main = checked_inspect(h, v, &n)?;
            if !main {
                for suffix in &SUFFIXES[1..] {
                    if checked_inspect(h, v, &format!("{n}{suffix}"))? {
                        return Err(err("OrphanedCompanions", n.clone()));
                    }
                }
            }
            let db = Connection::open(h.root.join(&n)).map_err(|e| err("Sqlite", e.to_string()))?;
            db.busy_timeout(Duration::from_millis(1000))
                .map_err(|e| err("Sqlite", e.to_string()))?;
            let id = v["handle"].as_str().unwrap_or("db").to_string();
            let mut s = h.state.lock().unwrap();
            if s.handles.contains_key(&id) {
                return Err(err("Handle", "Duplicate handle"));
            }
            s.handles
                .insert(id.clone(), (n.clone(), Arc::new(Mutex::new(Some(db)))));
            Ok(json!({"handle":id}))
        })();
        if opened.is_err() {
            let mut s = h.state.lock().unwrap();
            *s.live.get_mut(&n).unwrap() -= 1;
        }
        return opened;
    }
    if op == "delete" {
        let n = name(v)?;
        {
            let mut s = h.state.lock().unwrap();
            if s.live.get(&n).copied().unwrap_or(0) > 0 || s.deleting.contains_key(&n) {
                return Err(err("Busy", "Tracked opening/live/closing/delete"));
            }
            s.deleting.insert(n.clone(), true);
        }
        let result = (|| {
            checkpoint(h, v, "before-main");
            let mut failures = vec![];
            let mut removed = vec![];
            for (index, suffix) in SUFFIXES.iter().enumerate() {
                let file = format!("{n}{suffix}");
                let result = (|| {
                    if checked_inspect(h, v, &file)? {
                        if fault(v, "failRemove", &file) {
                            return Err(err("Remove", format!("Injected unlink failure: {file}")));
                        }
                        fs::remove_file(h.root.join(&file))
                            .map_err(|e| err("Remove", format!("{file}: {e}")))?;
                    }
                    Ok(())
                })();
                match result {
                    Ok(()) => removed.push(file.clone()),
                    Err(error) => {
                        failures.push(json!({"path":file,"error":error}));
                        if index == 0 {
                            return Err(
                                json!({"code":"DeleteFailed","failures":failures,"attempted":removed}),
                            );
                        }
                    }
                }
                checkpoint(
                    h,
                    v,
                    ["after-main", "after-journal", "after-wal", "after-shm"][index],
                );
            }
            for suffix in SUFFIXES {
                let file = format!("{n}{suffix}");
                match checked_inspect(h, v, &file) {
                    Ok(false) => (),
                    Ok(true) => {
                        failures.push(json!({"path":file,"error":err("Remaining","File remains")}))
                    }
                    Err(error) => failures.push(json!({"path":file,"error":error})),
                }
            }
            if failures.is_empty() {
                Ok(json!({"absent":true,"attempted":removed}))
            } else {
                Err(json!({"code":"DeleteFailed","failures":failures,"attempted":removed}))
            }
        })();
        h.state.lock().unwrap().deleting.remove(&n);
        return result;
    }
    let id = v["handle"].as_str().unwrap_or("db");
    let (n, conn) = {
        let mut s = h.state.lock().unwrap();
        if op == "close" {
            s.handles.remove(id)
        } else {
            s.handles.get(id).cloned()
        }
        .ok_or(err("Closed", "Unknown handle"))?
    };
    if op == "close" {
        // Removal from handle admission happens now; live count remains until physical release.
        emit(h, json!({"event":"closing","id":v["id"]}));
        delay(v);
        conn.lock().unwrap().take();
        let mut s = h.state.lock().unwrap();
        *s.live.get_mut(&n).unwrap() -= 1;
        return Ok(Value::Null);
    }
    let mut guard = conn.lock().unwrap();
    let db = guard.as_mut().ok_or(err("Closed", "Connection closed"))?;
    let convert = |a: &Value| -> Result<Vec<SqlValue>, Value> {
        a.as_array()
            .map(|a| {
                a.iter()
                    .map(|v| match v {
                        Value::Null => Ok(SqlValue::Null),
                        Value::String(s) => Ok(SqlValue::Text(s.clone())),
                        Value::Number(n) => Ok(SqlValue::Real(
                            n.as_f64().ok_or(err("Value", "Not number"))?,
                        )),
                        _ => Err(err("Value", "Not scalar")),
                    })
                    .collect()
            })
            .unwrap_or(Ok(vec![]))
    };
    if op == "all" {
        let sql = v["sql"].as_str().unwrap_or("");
        let mut stmt = db.prepare(sql).map_err(|e| err("Sqlite", e.to_string()))?;
        if !stmt.readonly() {
            return Err(err("Sqlite", "all requires readonly"));
        }
        let names: Vec<String> = stmt.column_names().iter().map(|s| s.to_string()).collect();
        let params = convert(&v["params"])?;
        let mut rows = stmt
            .query(params_from_iter(params))
            .map_err(|e| err("Sqlite", e.to_string()))?;
        let mut out = vec![];
        while let Some(row) = rows.next().map_err(|e| err("Sqlite", e.to_string()))? {
            let mut obj = serde_json::Map::new();
            for (i, n) in names.iter().enumerate() {
                let value = match row.get_ref(i).map_err(|e| err("Sqlite", e.to_string()))? {
                    ValueRef::Null => Value::Null,
                    ValueRef::Integer(n) => json!(n),
                    ValueRef::Real(n) => json!(n),
                    ValueRef::Text(s) => json!(String::from_utf8_lossy(s)),
                    _ => return Err(err("Value", "Blob unsupported")),
                };
                obj.insert(n.clone(), value);
            }
            out.push(Value::Object(obj));
        }
        return Ok(json!(out));
    }
    if op == "batch" || op == "run" {
        let statements = if op == "run" {
            vec![json!({"sql":v["sql"],"params":v["params"]})]
        } else {
            v["statements"].as_array().cloned().unwrap_or_default()
        };
        let tx = db.transaction().map_err(|e| err("Sqlite", e.to_string()))?;
        let mut changes = vec![];
        for st in statements {
            let params = convert(&st["params"])?;
            let c = tx
                .execute(st["sql"].as_str().unwrap_or(""), params_from_iter(params))
                .map_err(|e| err("Sqlite", e.to_string()))?;
            changes.push(c);
        }
        tx.commit().map_err(|e| err("Sqlite", e.to_string()))?;
        return Ok(if op == "run" {
            json!({"changes":changes[0]})
        } else {
            json!({"changes":changes})
        });
    }
    if op == "crash-fixture" {
        db.execute_batch(if v["mode"]=="wal" {"PRAGMA journal_mode=WAL; PRAGMA wal_autocheckpoint=0; CREATE TABLE fictional(value TEXT); INSERT INTO fictional VALUES ('committed fictional WAL');"}else{"PRAGMA journal_mode=DELETE; CREATE TABLE fictional(value TEXT); INSERT INTO fictional VALUES ('before'); BEGIN IMMEDIATE; UPDATE fictional SET value='uncommitted';"}).map_err(|e|err("Sqlite",e.to_string()))?;
        db.cache_flush().map_err(|e| err("Sqlite", e.to_string()))?;
        checkpoint(h, v, "crash-fixture-ready");
        return Ok(Value::Null);
    }
    Err(err("Operation", op))
}
fn main() {
    let root = std::env::args().nth(1).expect("fictional scratch root");
    let root = PathBuf::from(root);
    fs::create_dir_all(&root).unwrap();
    let root = fs::canonicalize(root).unwrap();
    assert!(
        root.to_string_lossy()
            .contains("/experiments/sqlite-delete/results/"),
        "Only this experiment's fictional results roots"
    );
    let h = Host {
        root,
        state: Default::default(),
        output: Default::default(),
    };
    for line in io::stdin().lock().lines() {
        let v: Value = serde_json::from_str(&line.unwrap()).unwrap();
        let h = h.clone();
        thread::spawn(move || {
            let id = v["id"].clone();
            match operation(&h, &v) {
                Ok(value) => emit(&h, json!({"id":id,"ok":true,"value":value})),
                Err(error) => emit(&h, json!({"id":id,"ok":false,"error":error})),
            }
        });
    }
}
