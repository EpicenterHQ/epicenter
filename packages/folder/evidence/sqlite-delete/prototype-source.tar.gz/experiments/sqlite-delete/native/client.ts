/** Task-only transport to Rust; app identity/path authority would be runtime-bound. */
import { join } from 'node:path';
export class NativeHost {
  child: ReturnType<typeof Bun.spawn>;
  events: any[] = [];
  next = 0;
  pending = new Map<number, (value: any) => void>();
  constructor(root: string) {
    this.child = Bun.spawn([join(import.meta.dir, 'target/debug/sqlite-delete-probe'), root], { stdin: 'pipe', stdout: 'pipe', stderr: 'inherit' });
    void this.read();
  }
  async read() {
    let text = '';
    for await (const part of this.child.stdout as ReadableStream<Uint8Array>) {
      text += new TextDecoder().decode(part);
      let cut;
      while ((cut = text.indexOf('\n')) >= 0) {
        const data = JSON.parse(text.slice(0, cut)); text = text.slice(cut + 1);
        if (data.event) this.events.push(data);
        else { this.pending.get(data.id)?.(data); this.pending.delete(data.id); }
      }
    }
    for (const [id, resolve] of this.pending) resolve({ id, ok: false, error: { code: 'Interrupted' } });
    this.pending.clear();
  }
  request(data: any) {
    const id = ++this.next;
    return new Promise<any>(resolve => { this.pending.set(id, resolve); (this.child.stdin as any).write(JSON.stringify({ ...data, id }) + '\n'); });
  }
  async call(data: any) { const result = await this.request(data); if (!result.ok) throw Object.assign(new Error(result.error.message ?? result.error.code), result.error); return result.value; }
  async kill() { this.child.kill('SIGKILL'); await this.child.exited; }
  sqlite = {
    open: async (path: string, options: any = {}) => {
      const handle = 'handle-' + (this.next + 1);
      await this.call({ op: 'open', path, handle, ...options });
      let closing: Promise<void> | undefined;
      const call = (data: any) => closing ? Promise.reject(Object.assign(new Error('Closed'), { code: 'Closed' })) : this.call({ ...data, handle });
      const db = {
        all: (sql: string, params: any[] = []) => call({ op: 'all', sql, params }),
        run: (sql: string, params: any[] = []) => call({ op: 'run', sql, params }),
        batch: (statements: any[]) => call({ op: 'batch', statements }),
        close: (options: any = {}) => closing ??= this.call({ op: 'close', handle, ...options }),
        [Symbol.asyncDispose]() { return this.close(); },
      };
      return db;
    },
    delete: (path: string, options: any = {}) => this.call({ op: 'delete', path, ...options }),
  };
}
