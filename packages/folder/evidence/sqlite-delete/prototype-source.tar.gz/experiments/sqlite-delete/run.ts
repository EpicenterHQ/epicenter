/** Fictional-only interruption checks; bun run.ts [--native-only|--browser-only]. */
import { mkdir, writeFile, readFile, readdir, rm, mkdtemp } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { chromium, firefox, webkit } from './baseline-browser/node_modules/playwright';
import { NativeHost } from './native/client';
const here = import.meta.dir;
const output = join(here, 'results', new Date().toISOString().replaceAll(':', '-'));
await mkdir(output, { recursive: true });
const evidence: any = { started: new Date().toISOString(), fictionalOnly: true, native: [], browser: [], limitations: ['Native Rust core host, not Tauri invoke/window integration.', 'Browser interruption is actual deletion-worker termination, then fresh page and profile reopen; not power loss.', 'Known ownership covers one native host or one browser tab; external clients must be quiescent.', 'Synthetic reserved companions are fixtures, not proof of WAL replay.', 'SQL harness tests rollback and handle lifetime, not the earlier full SQL guard/parity suite.'] };
function check(value: any, message: string): asserts value { if (!value) throw new Error(message); }
async function rejects(operation: Promise<any>, code?: string) { try { await operation; throw new Error('Expected failure'); } catch (e: any) { if (e.message === 'Expected failure') throw e; if (code) check(e.code === code, `Expected ${code}, got ${e.code}: ${e.message}`); return { code: e.code, message: e.message, failures: e.failures, attempted: e.attempted }; } }
async function until(test: () => boolean, message: string) { const end = Date.now() + 15000; while (!test()) { check(Date.now() < end, message); await Bun.sleep(10); } }
function record(target: any[], name: string, value: any = true) { target.push({ name, value }); console.log(JSON.stringify({ name, value })); }
const cuts = ['before-main', 'after-main', 'after-journal', 'after-wal', 'after-shm'];
const family = ['', '-journal', '-wal', '-shm'];
const p = 'fictional.sqlite';
async function nativeChecks() {
 const target = evidence.native;
 const root = join(output, 'native-fictional'); await mkdir(root);
 let host = new NativeHost(root);
 const names = async () => (await readdir(root)).sort();
 const seed = async () => {
   await host.sqlite.delete(p);
   const db = await host.sqlite.open(p); await db.run('CREATE TABLE original(value TEXT)'); await db.run("INSERT INTO original VALUES ('fictional only')"); await db.close();
   for (const suffix of family.slice(1)) await writeFile(join(root, p + suffix), 'fictional reserved companion');
   await writeFile(join(root, p + '.neighbor'), 'KEEP');
 };
 try {
  for (let i = 0; i < cuts.length; i++) {
   const cut = cuts[i]; await seed(); const originalBytes = await readFile(join(root, p)); host.events.length = 0;
   const pending = rejects(host.sqlite.delete(p, { pauseAt: cut }), 'Interrupted');
   await until(() => host.events.some(e => e.step === cut), 'Native deletion checkpoint missing');
   if (i === 0) {
     record(target, 'open-refuses-admitted-delete', await rejects(host.sqlite.open(p), 'Busy'));
     record(target, 'second-delete-refuses-admitted-delete', await rejects(host.sqlite.delete(p), 'Busy'));
   }
   await host.kill(); await pending;
   host = new NativeHost(root);
   const before = await names();
   if (i === 0) check(originalBytes.equals(await readFile(join(root, p))), 'Before-main interruption changed main bytes');
   const remaining = family.filter((_, index) => index >= i).map(s => p + s);
   check(remaining.every(n => before.includes(n)) && family.filter((_, index) => index < i).every(s => !before.includes(p + s)), 'Wrong family after native kill at ' + cut);
   if (i > 0 && i < 4) await rejects(host.sqlite.open(p), 'OrphanedCompanions');
   await host.sqlite.delete(p); await host.sqlite.delete(p);
   check((await names()).join(',') === p + '.neighbor', 'Retry did not clean exact family'); check((await readFile(join(root,p+'.neighbor'),'utf8'))==='KEEP','Neighbor bytes changed');
   const fresh = await host.sqlite.open(p); check((await fresh.all("SELECT name FROM sqlite_master WHERE type='table'")).length === 0, 'Recreated database retained table'); await fresh[Symbol.asyncDispose]();
   record(target, 'SIGKILL-restart-retry-' + cut, { remaining, neighborPreserved: true, retryIdempotent: true });
  }
  await seed();
  for (const cut of ['after-main', 'after-journal']) { host.events.length=0; const pending=rejects(host.sqlite.delete(p,{pauseAt:cut}),'Interrupted'); await until(()=>host.events.some(e=>e.step===cut),'Retry checkpoint missing'); await host.kill(); await pending; host=new NativeHost(root); }
  for(let attempt=0;attempt<2;attempt++) await rejects(host.sqlite.delete(p,{failRemove:[p+'-wal']}),'DeleteFailed');
  await host.sqlite.delete(p); record(target,'interrupted-retry-and-repeated-cleanup-failure');
  await writeFile(join(root,p+'-wal.backup'),'LOOKALIKE'); await host.sqlite.delete(p); check(await readFile(join(root,p+'-wal.backup'),'utf8')==='LOOKALIKE','Lookalike changed'); await rm(join(root,p+'-wal.backup')); record(target,'suffix-lookalike-preserved');
  await host.sqlite.delete(p);
  const db = await host.sqlite.open(p); await db.run('CREATE TABLE counter(value INTEGER UNIQUE)'); await db.run('INSERT INTO counter VALUES (1)');
  record(target,'sqlite-version',await db.all('SELECT sqlite_version() AS version'));
  const failed = await rejects(db.batch([{ sql: 'UPDATE counter SET value=2' }, { sql: 'INSERT INTO counter VALUES (2)' }]));
  check(JSON.stringify(await db.all('SELECT value FROM counter')) === '[{"value":1}]', 'Native batch not rolled back');
  record(target, 'atomic-batch-rollback', failed);
  record(target, 'live-connection-busy', await rejects(host.sqlite.delete(p), 'Busy'));
  const closing = db.close({ delayMs: 200 }); const closingId = host.next;
  await until(() => host.events.some(e => e.event === 'closing' && e.id === closingId), 'Native closing event missing');
  record(target, 'closing-connection-busy', await rejects(host.sqlite.delete(p), 'Busy'));
  await Promise.all([closing, db.close()]); await host.sqlite.delete(p);
  host.events.length=0; const opening = host.sqlite.open(p, { delayMs: 200 }); const openingId=host.next; await until(()=>host.events.some(e=>e.event==='opening' && e.id===openingId),'Opening event missing');
  record(target, 'opening-connection-busy', await rejects(host.sqlite.delete(p), 'Busy'));
  await (await opening).close(); await host.sqlite.delete(p);
  for (const failureType of ['failRemove', 'failInspect']) {
   for (const suffix of family) {
    await seed(); const fail = p + suffix;
    const error = await rejects(host.sqlite.delete(p, { [failureType]: [fail] }), 'DeleteFailed');
    const after = await names();
    if (!suffix) check(family.every(s => after.includes(p + s)), 'Main failure touched companions');
    else check(after.includes(fail) && family.filter(s => s !== suffix).every(s => !after.includes(p + s)), 'Companion error prevented later cleanup');
    await rejects(host.sqlite.open(p, { failInspect: [p] }), 'Inspect');
    await host.sqlite.delete(p);
    record(target, failureType + '-' + (suffix || 'main') + '-retry', error);
   }
  }
  for (const suffix of family) for (const nonempty of [false, true]) {
   await seed(); await rm(join(root, p + suffix)); await mkdir(join(root, p + suffix));
   if (nonempty) await writeFile(join(root, p + suffix, 'keep'), 'KEEP');
   await rejects(host.sqlite.delete(p), 'DeleteFailed');
   check((await readdir(join(root, p + suffix))).length === (nonempty ? 1 : 0), 'Directory removed/changed');
   await rm(join(root, p + suffix), { recursive: true }); await host.sqlite.delete(p);
   record(target, 'directory-preserved-' + (suffix || 'main') + '-' + nonempty);
  }
  for (const mode of ['wal', 'journal']) {
   await host.sqlite.delete(p); await host.sqlite.open(p, { });
   host.events.length = 0;
   const pending = rejects(host.call({ op: 'crash-fixture', handle: 'handle-' + host.next, mode, pauseAt: 'crash-fixture-ready' }), 'Interrupted');
   // The last opened facade's handle id is not the request sequence after call; derive from response naming above.
   await until(() => host.events.some(e => e.step === 'crash-fixture-ready'), 'Crash fixture checkpoint missing');
   await host.kill(); await pending; host = new NativeHost(root);
   const before = await names();
   check(before.includes(p + (mode === 'wal' ? '-wal' : '-journal')), 'SQLite did not leave actual companion');
   await host.sqlite.delete(p); check((await names()).join(',') === p + '.neighbor', 'Real companion cleanup failed');
   record(target, 'real-engine-' + mode + '-SIGKILL-cleanup', { before });
  }
  await writeFile(join(root, p), 'corrupt fictional database');
  await host.sqlite.delete(p); record(target, 'corrupt-unopened-main-deletable');
 } finally { await host.kill(); }
}
const headers = { 'Cross-Origin-Opener-Policy': 'same-origin', 'Cross-Origin-Embedder-Policy': 'require-corp', 'Cache-Control': 'no-store' };
async function browserChecks() {
 const scripts = new Map<string, string>();
 for (const entry of ['client', 'worker']) {
  const build = await Bun.build({ entrypoints: [join(here, 'browser', entry + '.ts')], target: 'browser', external: ['@sqlite.org/sqlite-wasm'] });
  if (!build.success) throw new AggregateError(build.logs, 'Browser build');
  scripts.set('/' + entry + '.js', (await build.outputs[0]!.text()).replaceAll('@sqlite.org/sqlite-wasm', '/vendor/index.mjs'));
 }
 const server = Bun.serve({ hostname: '127.0.0.1', port: 0, fetch(req) {
  const path = new URL(req.url).pathname;
  if (scripts.has(path)) return new Response(scripts.get(path), { headers: { ...headers, 'Content-Type': 'text/javascript' } });
  if (path.startsWith('/vendor/') && !path.includes('..')) return new Response(Bun.file(join(here, 'baseline-browser/node_modules/@sqlite.org/sqlite-wasm/dist', path.slice(8))), { headers: { ...headers, 'Content-Type': path.endsWith('.wasm') ? 'application/wasm' : 'text/javascript' } });
  return new Response('<!doctype html><title>Fictional SQLite delete prototype</title><script type="module" src="/client.js"></script>', { headers: { ...headers, 'Content-Type': 'text/html' } });
 } });
 try {
 for (const [engine, browserType] of Object.entries({ chromium, firefox, webkit })) {
  const report: any = { engine, cases: [] }; evidence.browser.push(report);
  const profile = await mkdtemp(join(tmpdir(), 'fictional-sqlite-delete-' + engine + '-'));
  let context: any; let page: any;
  const ready = async () => { page = await context.newPage(); await page.goto(server.url.href); await page.waitForFunction(() => !!(globalThis as any).probe); };
  const exec = (expression: string) => page.evaluate(async (expression: string) => { const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor; let fn; try { fn = new AsyncFunction('return (' + expression + ')'); } catch { fn = new AsyncFunction(expression); } return fn(); }, expression);
  const failure = (expression: string) => exec('(async()=>{try { await (' + expression + '); return {unexpectedSuccess:true}; }catch(e){return {code:e.code ?? e.name,message:e.message,failures:e.failures,attempted:e.attempted}}})()');
  const refused = async (expression: string, code: string) => { const error = await failure(expression); check(error.code === code, engine + ': expected ' + code + ': ' + JSON.stringify(error)); return error; };
  const files = () => exec('probe.files()');
  const recordBrowser = (name: string, value: any = true) => record(report.cases, engine + ':' + name, value);
  try {
   context = await browserType.launchPersistentContext(profile, { headless: true }); await ready();
   report.userAgent = await page.evaluate(() => navigator.userAgent);
   for (let i = 0; i < cuts.length; i++) {
    const cut = cuts[i]; await exec('probe.reset()'); await exec(`probe.seed('${p}')`);
    await exec(`globalThis.pending = probe.device.sqlite.delete('${p}', {pauseAt:'${cut}'}).catch(e=>({code:e.code})); undefined`);
    await page.waitForFunction((cut: string) => (globalThis as any).probe.checkpoints.some((e: any) => e.step === cut), cut);
    if (i === 0) { await refused(`probe.createDevice().sqlite.open('${p}')`, 'Busy'); await refused(`probe.createDevice().sqlite.delete('${p}')`, 'Busy'); recordBrowser('delete-admission-refuses-open-and-delete-across-device-handles'); }
    await exec('probe.interrupt()'); check((await exec('pending')).code === 'Interrupted', 'Worker termination did not reject pending delete');
    await page.close(); await ready();
    const before = await files(); const remaining = family.filter((_, index) => index >= i).map(s => p + s);
    check(remaining.every(n => before.includes(n)) && family.filter((_, index) => index < i).every(s => !before.includes(p + s)), 'Wrong browser family after cut ' + cut);
    if (i > 0 && i < 4) await refused(`probe.device.sqlite.open('${p}')`, 'OrphanedCompanions');
    await exec(`probe.device.sqlite.delete('${p}')`); await exec(`probe.device.sqlite.delete('${p}')`);
    check((await files()).join(',') === p + '.neighbor', 'Browser cleanup touched neighbor or left family'); check(JSON.stringify(await exec(`probe.bytes('${p}.neighbor')`))==='[75,69,69,80]','Browser neighbor bytes changed');
    await exec(`globalThis.db=await probe.device.sqlite.open('${p}'); if((await db.all("SELECT name FROM sqlite_master WHERE type='table'")).length)throw Error('Not empty'); await db[Symbol.asyncDispose]()`);
    recordBrowser('worker-terminate-page-restart-retry-' + cut, { remaining, neighborPreserved: true });
   }
   await exec(`await probe.reset(); await probe.seed('${p}')`);
   for (const cut of ['after-main','after-journal']) { await exec(`probe.checkpoints.length=0; globalThis.pending=probe.device.sqlite.delete('${p}',{pauseAt:'${cut}'}).catch(e=>({code:e.code}));`); await page.waitForFunction((cut:string)=>(globalThis as any).probe.checkpoints.some((e:any)=>e.step===cut),cut); await exec('probe.interrupt()'); await exec('pending'); await page.close(); await ready(); }
   for(let attempt=0;attempt<2;attempt++) await refused(`probe.device.sqlite.delete('${p}',{failRemove:['${p}-wal']})`,'DeleteFailed');
   await exec(`probe.device.sqlite.delete('${p}')`); recordBrowser('interrupted-retry-and-repeated-cleanup-failure');
   await exec(`await probe.write('${p}-wal.backup','LOOKALIKE'); await probe.device.sqlite.delete('${p}')`); check(JSON.stringify(await exec(`probe.bytes('${p}-wal.backup')`))==='[76,79,79,75,65,76,73,75,69]','Browser lookalike changed'); await exec(`probe.remove('${p}-wal.backup')`); recordBrowser('suffix-lookalike-preserved');
   await exec(`probe.device.sqlite.delete('${p}')`);
   const version = await exec(`globalThis.db=await probe.device.sqlite.open('${p}'); await db.run('CREATE TABLE counter(value INTEGER UNIQUE)'); await db.run('INSERT INTO counter VALUES (1)'); return await db.all('SELECT sqlite_version() AS version')`);
   await failure(`db.batch([{sql:'UPDATE counter SET value=2'},{sql:'INSERT INTO counter VALUES (2)'}])`);
   check(JSON.stringify(await exec("db.all('SELECT value FROM counter')")) === '[{"value":1}]', 'Browser rollback failed'); recordBrowser('atomic-batch-rollback', version);
   await refused(`probe.createDevice().sqlite.delete('${p}')`, 'Busy'); recordBrowser('live-connection-busy-across-device-handles');
   await exec('globalThis.closing=db.close({delayMs:200}); undefined'); await refused(`probe.device.sqlite.delete('${p}')`, 'Busy'); await exec('Promise.all([closing,db.close()])'); recordBrowser('closing-busy-and-idempotent-close');
   await exec(`probe.device.sqlite.delete('${p}')`);
   await exec(`globalThis.opening=probe.device.sqlite.open('${p}',{delayMs:200}); undefined`); await refused(`probe.device.sqlite.delete('${p}')`, 'Busy'); await exec('(await opening).close()'); recordBrowser('opening-busy');
   for (const failureType of ['failRemove', 'failInspect']) for (const suffix of family) {
    await exec('probe.reset()'); await exec(`probe.seed('${p}')`);
    const fail = p + suffix;
    const error = await refused(`probe.device.sqlite.delete('${p}',{${failureType}:['${fail}']})`, 'DeleteFailed'); const after = await files();
    if (!suffix) check(family.every(s => after.includes(p + s)), 'Browser main failure touched companions');
    else check(after.includes(fail) && family.filter(s => s !== suffix).every(s => !after.includes(p + s)), 'Browser companion failure prevented later cleanup');
    await refused(`probe.device.sqlite.open('${p}',{failInspect:['${p}']})`, 'Inspect');
    await exec(`probe.device.sqlite.delete('${p}')`); recordBrowser(failureType + '-' + (suffix || 'main') + '-retry', error);
   }
   for (const suffix of family) for (const nonempty of [false, true]) {
    await exec('probe.reset()'); await exec(`await probe.seed('${p}'); await probe.remove('${p + suffix}'); await probe.mkdir('${p + suffix}',${nonempty})`);
    await refused(`probe.device.sqlite.delete('${p}')`, 'DeleteFailed');
    check((await files()).includes(p + suffix), 'Browser directory removed');
    await exec(`probe.remove('${p + suffix}'); await probe.device.sqlite.delete('${p}')`); recordBrowser('directory-preserved-' + (suffix || 'main') + '-' + nonempty);
   }
   await exec('probe.reset()'); await exec(`globalThis.db=await probe.device.sqlite.open('${p}'); await db.run('CREATE TABLE saved(value TEXT)'); await db.run("INSERT INTO saved VALUES ('fictional restart')"); await db.close()`);
   await context.close(); context = await browserType.launchPersistentContext(profile, { headless: true }); await ready();
   const persisted = await exec(`globalThis.db=await probe.device.sqlite.open('${p}'); const rows=await db.all('SELECT value FROM saved'); await db.close(); return rows`);
   check(JSON.stringify(persisted) === '[{"value":"fictional restart"}]', 'Profile restart lost SQLite data'); await exec(`probe.device.sqlite.delete('${p}')`); recordBrowser('profile-reopen-and-cleanup', persisted);
   // A terminated database worker is conservatively tracked Busy until page retirement.
   await exec(`globalThis.db=await probe.device.sqlite.open('${p}'); probe.interrupt()`);
   await refused('db.close()', 'Closed'); await refused(`probe.device.sqlite.delete('${p}')`, 'Busy'); recordBrowser('worker-crash-retains-busy-until-page-retirement');
   await page.close(); await ready(); await exec(`probe.device.sqlite.delete('${p}')`);
  } finally { if (context) await context.close(); await rm(profile, { recursive: true, force: true }); }
 }
 } finally { server.stop(true); }
}
try {
 if (!Bun.argv.includes('--browser-only')) { const built=Bun.spawnSync(['/opt/homebrew/bin/cargo','build','--offline','--manifest-path',join(here,'native/Cargo.toml')],{stdout:'inherit',stderr:'inherit'}); check(built.exitCode===0,'Native build failed'); await nativeChecks(); }
 if (!Bun.argv.includes('--native-only')) await browserChecks();
 evidence.passed = true;
} catch (error: any) { evidence.passed = false; evidence.error = { message: error.message, stack: error.stack }; process.exitCode = 1; console.error(error); }
finally { evidence.finished = new Date().toISOString(); await writeFile(join(output, 'evidence.json'), JSON.stringify(evidence, null, 2)); await writeFile(join(here, 'results/latest.json'), JSON.stringify({ output, passed: evidence.passed }, null, 2)); console.log('Evidence: ' + join(output, 'evidence.json')); }
