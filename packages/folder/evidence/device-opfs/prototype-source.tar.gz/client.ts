/** THROWAWAY browser controller. Also exposes state for two-tab experiments. */
import { openDeviceStorage } from './device.js';
const device = await openDeviceStorage();
let db: Awaited<ReturnType<typeof device.openSqlite>> | undefined;
const probe = {
  device,
  async open(name = 'search.sqlite') { db = await device.openSqlite(name); return db.info; },
  async close() { await db?.close(); db = undefined; },
  async all(sql: string, bind: (string | number | null)[] = []) { return db!.all(sql, bind); },
  async run(sql: string, bind: (string | number | null)[] = [], waitMs?: number) { return db!.run(sql, bind, waitMs); },
  async batch(statements: { sql: string; bind?: (string | number | null)[] }[]) { return db!.batch(statements); },
  async loop(label: string, count: number) {
    const start = performance.now();
    for (let i = 0; i < count; i++) await db!.batch([
      { sql: 'UPDATE counter SET value = value + 1' },
      { sql: 'INSERT INTO edits(tab, seq) VALUES (?, ?)', bind: [label, i] },
    ]);
    return { count, ms: performance.now() - start, retries: db!.getRetries() };
  },
  async terminate() {
    // Renderer/page destruction is tested by the browser harness, not this method.
    await device.close();
  },
};
declare global { var deviceProbe: typeof probe; }
globalThis.deviceProbe = probe;
document.body.innerHTML = '<h1>Device OPFS prototype</h1><p>Fictional data in a disposable browser profile. Use deviceProbe in the console.</p><pre id="state"></pre>';
setInterval(async () => {
  document.querySelector('#state')!.textContent = JSON.stringify({ isolated: crossOriginIsolated, files: await device.files.list(), locks: await navigator.locks.query() }, null, 2);
}, 1000);
