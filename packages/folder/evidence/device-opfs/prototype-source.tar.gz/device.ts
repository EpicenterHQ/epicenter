/** THROWAWAY: a single fixed, origin-bound OPFS root, not a production API. */
const ROOT = 'PROTOTYPE-wipe-me-device-opfs';

function fileName(name: string) {
  if (!name || name === '.' || name === '..' || /[/\\\0]/.test(name)) throw new Error('Prototype accepts one filename');
  return name;
}
function busy() { const error = new Error('Close every SQLite connection before raw access'); error.name = 'FileBusy'; return error; }
const lockName = (name: string) => `prototype-file:/${ROOT}/${fileName(name)}`;

/** Shared for connection lifetime; exclusive for each cooperating raw operation. */
async function lease(name: string) {
  let release!: () => void;
  const held = new Promise<void>(resolve => { release = resolve; });
  return new Promise<() => void>((resolve, reject) => {
    void navigator.locks.request(lockName(name), { mode: 'shared', ifAvailable: true }, async lock => {
      if (!lock) { reject(busy()); return; }
      resolve(release);
      await held;
    }).catch(reject);
  });
}

export async function openDeviceStorage() {
  const root = await (await navigator.storage.getDirectory()).getDirectoryHandle(ROOT, { create: true });
  const connections = new Set<{ close(): Promise<void> }>();
  const raw = {
    async read(name: string) {
      const file = await (await root.getFileHandle(fileName(name))).getFile();
      return new Uint8Array(await file.arrayBuffer());
    },
    async write(name: string, content: string | Uint8Array) {
      const handle = await root.getFileHandle(fileName(name), { create: true });
      const stream = await handle.createWritable();
      await stream.write(content as FileSystemWriteChunkType);
      await stream.close();
    },
    async delete(name: string) { await root.removeEntry(fileName(name)); },
    async list() {
      const names: string[] = [];
      const iterable = root as FileSystemDirectoryHandle & { keys(): AsyncIterableIterator<string> };
      for await (const name of iterable.keys()) names.push(name);
      return names.sort();
    },
  };
  async function exclusive<T>(name: string, operation: () => Promise<T>) {
    return navigator.locks.request(lockName(name), { mode: 'exclusive', ifAvailable: true }, lock => {
      if (!lock) throw busy();
      return operation();
    });
  }
  return {
    files: {
      list: raw.list,
      read: (name: string) => exclusive(name, () => raw.read(name)),
      write: (name: string, content: string | Uint8Array) => exclusive(name, () => raw.write(name, content)),
      delete: (name: string) => exclusive(name, () => raw.delete(name)),
    },
    // Experiment-only bypass distinguishes browser behavior from our lease policy.
    unprotected: raw,
    async openSqlite(name: string) {
      const release = await lease(name);
      const worker = new Worker('/sqlite-worker.js' + location.search, { type: 'module' });
      let sequence = 0;
      let retries = 0;
      let closing: Promise<void> | undefined;
      const pending = new Map<number, { resolve(value: unknown): void; reject(error: Error): void }>();
      worker.onmessage = ({ data }) => {
        retries += data.retries;
        const reply = pending.get(data.id);
        if (!reply) return;
        pending.delete(data.id);
        if (data.error) reply.reject(Object.assign(new Error(data.error.message), data.error));
        else reply.resolve(data.value);
      };
      worker.onerror = event => {
        for (const reply of pending.values()) reply.reject(new Error(event.message));
        pending.clear();
      };
      function call(action: string, args = {}): Promise<unknown> {
        const id = sequence++;
        return new Promise((resolve, reject) => {
          pending.set(id, { resolve, reject });
          worker.postMessage({ id, action, ...args });
        });
      }
      let info: unknown;
      try { info = await call('open', { path: `/${ROOT}/${fileName(name)}` }); }
      catch (error) { worker.terminate(); release(); throw error; }
      const connection = {
        info,
        all: (sql: string, bind: (string | number | null)[] = []) => call('all', { sql, bind }),
        run: (sql: string, bind: (string | number | null)[] = [], waitMs = 5000) => call('run', { sql, bind, waitMs }),
        batch: (statements: { sql: string; bind?: (string | number | null)[] }[]) => call('batch', { statements }),
        getRetries: () => retries,
        close() {
          closing ??= call('close').then(() => {
            worker.terminate();
            release();
            connections.delete(connection);
          });
          return closing;
        },
      };
      connections.add(connection);
      return connection;
    },
    async close() { await Promise.all([...connections].map(connection => connection.close())); },
  };
}
