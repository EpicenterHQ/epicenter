/** THROWAWAY evidence harness. Run: bun run.ts [--manual]. No real user data. */
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { chromium, firefox, webkit, type Page } from 'playwright';
import type {} from './client.js';

const scripts = new Map<string, string>();
for (const entry of ['client', 'sqlite-worker']) {
  const build = await Bun.build({ entrypoints: [join(import.meta.dir, entry + '.ts')], target: 'browser', external: ['@sqlite.org/sqlite-wasm'] });
  if (!build.success) throw new AggregateError(build.logs, 'Build failed');
  scripts.set('/' + entry + '.js', (await build.outputs[0]!.text()).replaceAll('@sqlite.org/sqlite-wasm', '/vendor/index.mjs'));
}
const headers = {
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Embedder-Policy': 'require-corp',
  'Cache-Control': 'no-store',
};
const html = '<!doctype html><title>Device OPFS prototype</title><body><script type="module" src="/client.js"></script>';
const server = Bun.serve({
  hostname: '127.0.0.1', port: 0,
  fetch(request) {
    const path = new URL(request.url).pathname;
    const isolated = !path.startsWith('/without-headers');
    const common = isolated ? headers : { 'Cache-Control': 'no-store' };
    if (scripts.has(path)) return new Response(scripts.get(path), { headers: { ...common, 'Content-Type': 'text/javascript' } });
    if (path.startsWith('/vendor/') && !path.includes('..')) {
      const file = Bun.file(join(import.meta.dir, 'node_modules/@sqlite.org/sqlite-wasm/dist', path.slice(8)));
      return new Response(file, { headers: { ...common, 'Content-Type': path.endsWith('.wasm') ? 'application/wasm' : 'text/javascript' } });
    }
    return new Response(html, { headers: { ...common, 'Content-Type': 'text/html' } });
  },
});
if (Bun.argv.includes('--manual')) {
  console.log('Prototype server: ' + server.url);
  console.log('Run the browser console: await deviceProbe.open(); await deviceProbe.run("CREATE TABLE demo(value TEXT)")');
  await new Promise(() => {});
}

function check(value: unknown, message: string): asserts value {
  if (!value) throw new Error(message);
}
async function result(page: Page, expression: string) {
  return page.evaluate(async expression => {
    const start = performance.now();
    try {
      return { ok: true, value: await (0, eval)(expression), ms: performance.now() - start };
    } catch (error) {
      return { ok: false, name: (error as Error).name, message: (error as Error).message, code: (error as { code?: number }).code, ms: performance.now() - start };
    }
  }, expression);
}
async function ready(page: Page, path = '') {
  page.setDefaultTimeout(20_000);
  page.on('pageerror', error => console.error('Page error: ' + error.message));
  const url = new URL(path, server.url);
  url.searchParams.set('vfs', Bun.argv.find(arg => arg.startsWith('--vfs='))?.slice(6) ?? 'opfs');
  await page.goto(url.href);
  await page.waitForFunction(() => !!globalThis.deviceProbe);
}

const evidence: { browser: string; version?: string; cases: { name: string; value: unknown }[]; error?: string }[] = [];
try {
  for (const [browserName, browserType] of Object.entries({ chromium, firefox, webkit })) {
    const profile = await mkdtemp(join(tmpdir(), 'PROTOTYPE-wipe-me-opfs-' + browserName + '-'));
    const report: (typeof evidence)[number] = { browser: browserName, cases: [] };
    evidence.push(report);
    let context: Awaited<ReturnType<typeof chromium.launchPersistentContext>> | undefined;
    const record = (name: string, value: unknown) => {
      report.cases.push({ name, value });
      console.log(JSON.stringify({ browser: browserName, name, value }));
    };
    try {
      context = await browserType.launchPersistentContext(profile, { headless: true });
      report.version = context.browser()?.version();
      const a = await context.newPage();
      const b = await context.newPage();
      await ready(a);
      await ready(b);
      record('environment', await a.evaluate(() => ({ userAgent: navigator.userAgent, isolated: crossOriginIsolated, webLocks: !!navigator.locks })));
      const opened = await a.evaluate(() => deviceProbe.open());
      record('official-adapter', opened);
      await a.evaluate(() => deviceProbe.run('CREATE TABLE counter(value INTEGER); INSERT INTO counter VALUES (0); CREATE TABLE edits(tab TEXT, seq INTEGER, UNIQUE(tab, seq));'));
      await a.evaluate(() => deviceProbe.close());
      const file = await a.evaluate(async () => {
        const bytes = await deviceProbe.device.files.read('search.sqlite');
        return { names: await deviceProbe.device.files.list(), size: bytes.length, header: new TextDecoder().decode(bytes.slice(0, 16)) };
      });
      check(file.header === 'SQLite format 3\0', 'Not an ordinary SQLite file');
      record('sqlite-visible-through-files', file);
      await b.evaluate(async () => {
        await deviceProbe.device.files.write('preferences.json', '{"sidebar":true}');
        const bytes = await deviceProbe.device.files.read('search.sqlite');
        await deviceProbe.device.files.write('copy.sqlite', bytes);
        await deviceProbe.open('copy.sqlite');
      });
      const copied = await b.evaluate(() => deviceProbe.all('SELECT value FROM counter'));
      check(JSON.stringify(copied) === '[{"value":0}]', 'Raw byte copy not readable as SQLite');
      record('file-copy-opened-by-sqlite-in-other-tab', copied);
      await b.evaluate(() => deviceProbe.close());
      await a.evaluate(() => deviceProbe.open());
      await b.evaluate(() => deviceProbe.open());
      const shared = await b.evaluate(() => deviceProbe.all('SELECT value FROM counter'));
      record('two-tabs-open-same-file', shared);
      if (Bun.argv.includes('--contention-only')) {
        await a.evaluate(() => deviceProbe.run('BEGIN EXCLUSIVE'));
        const pending = result(b, 'deviceProbe.run("UPDATE counter SET value = value + 1")');
        await new Promise(resolve => setTimeout(resolve, 100));
        await a.evaluate(() => deviceProbe.run('ROLLBACK'));
        const released = await pending;
        check(released.ok, 'Short contention did not recover');
        record('short-contention-release-after-100ms', released);
        await a.evaluate(() => deviceProbe.run('BEGIN EXCLUSIVE'));
        const held = result(b, 'deviceProbe.run("UPDATE counter SET value = value + 1", [], 150)');
        if (Bun.argv.includes('--hold-until-error')) {
          record('held-contention-150ms-retry-budget', await held);
          await a.evaluate(() => deviceProbe.run('ROLLBACK'));
          await b.evaluate(() => deviceProbe.run('UPDATE counter SET value = value + 1'));
          record('query-after-contention', await b.evaluate(() => deviceProbe.all('SELECT value FROM counter')));
          continue;
        }
        const observed = await Promise.race([
          held.then(value => ({ settled: true, value })),
          new Promise<{ settled: false }>(resolve => setTimeout(() => resolve({ settled: false }), 3000)),
        ]);
        record('held-contention-150ms-budget-after-3s', observed);
        await a.evaluate(() => deviceProbe.run('ROLLBACK'));
        record('held-request-after-owner-releases', await held);
        await b.evaluate(() => deviceProbe.run('UPDATE counter SET value = value + 1'));
        record('query-after-contention', await b.evaluate(() => deviceProbe.all('SELECT value FROM counter')));
        continue;
      }

      for (const [operation, expression] of [
        ['read', 'deviceProbe.device.files.read("search.sqlite")'],
        ['write', 'deviceProbe.device.files.write("search.sqlite", "unsafe")'],
        ['delete', 'deviceProbe.device.files.delete("search.sqlite")'],
      ]) {
        const refused = await result(b, expression);
        check(!refused.ok && refused.name === 'FileBusy', 'Cooperating raw ' + operation + ' did not refuse active DB');
        record('lease-refuses-active-raw-' + operation, refused);
      }
      // Raw operations remain busy when just this tab has closed.
      await a.evaluate(() => deviceProbe.close());
      const oneClosed = await result(a, 'deviceProbe.device.files.read("search.sqlite")');
      check(!oneClosed.ok && oneClosed.name === 'FileBusy', 'Other tab lease was ignored');
      record('other-tab-still-owns-file', oneClosed);
      await a.evaluate(() => deviceProbe.open());
      const writes = await Promise.all([
        a.evaluate(() => deviceProbe.loop('A', 100)),
        b.evaluate(() => deviceProbe.loop('B', 100)),
      ]);
      const totals = await a.evaluate(() => deviceProbe.all('SELECT value, (SELECT count(*) FROM edits) AS edits FROM counter'));
      check(JSON.stringify(totals) === '[{"value":200,"edits":200}]', 'Concurrent atomic edits lost or duplicated');
      record('two-tab-200-atomic-batches', { writes, totals });
      const rollback = await result(a, 'deviceProbe.batch([{sql:"UPDATE counter SET value = 999"}, {sql:"INSERT INTO edits(tab, seq) VALUES (\'A\', 0)"}])');
      check(!rollback.ok, 'Constraint batch did not fail');
      check(JSON.stringify(await a.evaluate(() => deviceProbe.all('SELECT value FROM counter'))) === '[{"value":200}]', 'Failed batch did not roll back');
      record('failed-batch-rolls-back', rollback);

      // Deliberately exposed probe-only transaction commands establish real contention.
      await a.evaluate(() => deviceProbe.run('BEGIN EXCLUSIVE'));
      const blocked = await result(b, 'deviceProbe.run("UPDATE counter SET value = value + 1", [], 150)');
      check(!blocked.ok, 'Exclusive transaction failed to contend');
      await a.evaluate(() => deviceProbe.run('ROLLBACK'));
      await b.evaluate(() => deviceProbe.run('UPDATE counter SET value = value + 1'));
      record('contention-error-and-recovery', blocked);
      await b.evaluate(() => deviceProbe.close());
      await a.evaluate(() => deviceProbe.run('BEGIN EXCLUSIVE; UPDATE counter SET value = 9999'));
      await a.close();
      await b.evaluate(() => deviceProbe.open());
      const recovered = await b.evaluate(() => deviceProbe.all('SELECT value FROM counter'));
      check(JSON.stringify(recovered) === '[{"value":201}]', 'Tab death retained uncommitted edit');
      record('tab-closed-mid-transaction-rolls-back', recovered);
      await b.evaluate(() => deviceProbe.close());
      const afterDeath = await b.evaluate(async () => (await deviceProbe.device.files.read('search.sqlite')).length);
      record('tab-death-releases-cooperating-file-lease', afterDeath);

      // Observe browser enforcement separately, only against disposable DB copies.
      for (const operation of ['read', 'write', 'delete']) {
        await b.evaluate(async operation => {
          const bytes = await deviceProbe.device.files.read('search.sqlite');
          await deviceProbe.device.files.write('unsafe-' + operation + '.sqlite', bytes);
          await deviceProbe.open('unsafe-' + operation + '.sqlite');
          await deviceProbe.run('BEGIN EXCLUSIVE');
        }, operation);
        const expression = operation === 'read'
          ? 'deviceProbe.device.unprotected.read("unsafe-read.sqlite").then(x => x.length)'
          : operation === 'write'
            ? 'deviceProbe.device.unprotected.write("unsafe-write.sqlite", new Uint8Array([1,2,3]))'
            : 'deviceProbe.device.unprotected.delete("unsafe-delete.sqlite")';
        record('browser-unprotected-live-' + operation, await result(b, expression));
        await result(b, 'deviceProbe.run("ROLLBACK")');
        await result(b, 'deviceProbe.close()');
      }
      const preferences = await b.evaluate(async () => new TextDecoder().decode(await deviceProbe.device.files.read('preferences.json')));
      check(preferences === '{"sidebar":true}', 'Ordinary file missed');
      record('ordinary-file-survives-next-to-database', preferences);

      await context.close();
      context = await browserType.launchPersistentContext(profile, { headless: true });
      const reopened = await context.newPage();
      await ready(reopened);
      await reopened.evaluate(() => deviceProbe.open());
      const durable = await reopened.evaluate(() => deviceProbe.all('PRAGMA integrity_check'));
      check(JSON.stringify(durable) === '[{"integrity_check":"ok"}]', 'Reopened database corrupt');
      check(JSON.stringify(await reopened.evaluate(() => deviceProbe.all('SELECT value FROM counter'))) === '[{"value":201}]', 'Full-profile reopen lost committed bytes');
      record('full-profile-reopen-integrity', durable);
      await reopened.evaluate(() => deviceProbe.close());
      const noHeaders = await context.newPage();
      await ready(noHeaders, '/without-headers');
      record('without-isolation-headers', await result(noHeaders, 'deviceProbe.open()'));
    } catch (error) {
      report.error = String(error);
      console.error(browserName + ': ' + error);
    } finally {
      await context?.close();
      await rm(profile, { recursive: true, force: true });
      const output = Bun.argv.find(arg => arg.startsWith('--output='))?.slice(9) ?? 'results.json';
      await Bun.write(join(import.meta.dir, output), JSON.stringify({ package: '@sqlite.org/sqlite-wasm@3.54.1-build1', playwright: '1.61.1', vfs: Bun.argv.find(arg => arg.startsWith('--vfs='))?.slice(6) ?? 'opfs', evidence }, null, 2));
    }
  }
} finally { server.stop(true); }
if (evidence.some(report => report.error)) process.exitCode = 1;
