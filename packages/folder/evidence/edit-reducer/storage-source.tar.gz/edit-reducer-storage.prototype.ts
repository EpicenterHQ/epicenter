/**
 * Throwaway exact-source differential experiment. Run from packages/folder:
 * bun src/edit-reducer-storage.prototype.ts
 *
 * Compare the frozen task-start owner with the sparse bounded candidate through
 * the real codec, handle, IndexedDB repository and guarded publication loop.
 * Only publication timing/failures and receipt delivery are controlled.
 */
import 'fake-indexeddb/auto';
import { IDBFactory } from 'fake-indexeddb';
import { Type } from 'typebox';
import { expectOk } from 'wellcrafted/testing';
import { openRepository } from './browser/repository.js';
import { StorageFailure } from './browser/storage.js';
import { folderHandle as reference } from './handle.reference.prototype.js';
import { folderHandle as candidate } from './handle.bounded.prototype.js';
import type { FileEdit } from './edit-owner.js';
import { frameRowText } from './shared/content/markdown.js';

const path = 'notes/a.md';
const repair = '---\ntitle: Old\nuntouched: keep\n---\none\ntwo\nthree\n';
const fixtures = [
	repair,
	"---\n# leading comment\ntitle: 'Old' # title comment\nuntouched: \"keep: quoted\"\n---\none\ntwo\nthree\n",
	"\uFEFF---\r\n# mark and CRLF\ntitle: 'Old' # title\nuntouched: keep\r\n---\r\none\r\ntwo\r\nthree\r\n".replaceAll(/(?<!\r)\n/g, '\r\n'),
	'---\ntitle: Old\nanchor: &a { n: 1 }\ncopy: *a\nbody: field body\n---\none\ntwo\nthree\n',
	'---\ntitle: Old\nuntouched: |\n  block\n  scalar\n---\none\ntwo\nthree\n',
	'---\ntitle: [broken\n---\none\ntwo\nthree\n',
	'---\ntitle: unfinished\none\ntwo\nthree\n',
	'plain source\nwith no fence\n',
];
const modes = ['success', 'failure', 'stale', 'presentation', 'malformed', 'unclosed', 'binary'] as const;
const prefixes = [[0], [2], [4], [0, 4], [6, 0], [0, 6], [1, 5], [7, 0], [8]];
const tails = [[0], [1], [2], [3], [4], [5], [6, 1], [0, 6], [7], [8], [8, 0], [9]];
const decoder = new TextDecoder('utf-8', { ignoreBOM: true });

function action(edit: FileEdit, step: number) {
	const text = edit.getText() ?? '';
	const newline = text.includes('\r\n') ? '\r\n' : '\n';
	switch (step) {
		case 0: return edit.change({ fields: { title: 'Mine' } });
		case 1: return edit.change({ fields: { title: 'Old' } });
		case 2: return edit.change({ body: (edit.getMarkdown()?.body ?? 'body\n') + `local${newline}` });
		case 3: return edit.change({ fields: { title: undefined, payload: { tags: ['owned'], count: 1 } } });
		case 4: return edit.replaceText(text + `source${newline}`);
		case 5: return edit.replaceText(text.replace('Mine', 'Old'));
		case 6: return edit.change({ fields: { title: 'Old', body: 'field body' } });
		case 7: return edit.change({ fields: Object.fromEntries([['__proto__', { kept: true }], ['title', 7]]) });
		case 8: return edit.replaceText(text.replace(/^(\uFEFF?---\r?\n|---\r?\n)/, `$1# local presentation${newline}`));
		case 9: return edit.replaceText(text.replace("'Old'", '"Old"').replace('title: Old', 'title: "Old"'));
		default: throw new Error(`Unknown action ${step}`);
	}
}

function snapshot(edit: FileEdit) {
	const pending = edit.getPending();
	const markdown = edit.getMarkdown();
	return {
		text: edit.getText(),
		markdown: markdown === undefined ? undefined : {
			text: markdown.text, fields: markdown.fields, body: markdown.body,
			issues: markdown.issues?.map(({ kind, path }) => ({ kind, path })) ?? null,
		},
		pending: pending === undefined ? undefined : {
			...pending, error: pending.error?.name,
		},
	};
}

async function run(factory: typeof reference, original: string, prefix: number[], tail: number[], mode: typeof modes[number]) {
	globalThis.indexedDB = new IDBFactory() as unknown as globalThis.IDBFactory;
	const id = crypto.randomUUID();
	const schemas = { notes: Type.Object({ title: Type.String() }) };
	const a = await openRepository(id, schemas);
	const b = await openRepository(id, schemas);
	const files = { ...a.files };
	const folder = factory({ files, tables: a.tables, subscribe: a.onChange, close: a.close }, schemas, { saveAfterMs: 60_000 });
	const edit = folder.files.edit(path);
	const events: unknown[] = [];
	let stalePublications = 0;
	let injectedFailures = 0;
	let bytesChecked = 0;
	let exactHeaderChecks = 0;
	let successfulRepairs = 0;
	let faulted = false;
	let armed = true;
	let failuresLeft = mode === 'failure' ? 2 : 0;
	const attempted = Promise.withResolvers<void>();
	const receipt = Promise.withResolvers<void>();
	const publish = a.storage.publish;
	const write = files.write;
	let gateFirst = true;
	try {
		expectOk(await b.files.write(path, null, original));
		expectOk(await edit.read());
		events.push({ stage: 'read', state: snapshot(edit), table: folder.tables.notes.edit('a').getMarkdown() });
		for (const step of prefix) events.push({ stage: 'prefix', step, accepted: action(edit, step).error?.name, state: snapshot(edit) });
		const frame = frameRowText(original);
		if (prefix.length === 1 && prefix[0] === 2 && frame.kind === 'frontmatter') {
			if (edit.getText()?.slice(0, frame.bodyStart) !== original.slice(0, frame.bodyStart)) throw new Error('A body-only edit rewrote the exact header');
			exactHeaderChecks++;
		}
		a.storage.publish = async (input) => {
			if (armed && failuresLeft > 0) {
				failuresLeft--; injectedFailures++;
				throw new StorageFailure('injected publication failure');
			}
			if (armed && !faulted && mode !== 'success' && mode !== 'failure') {
				faulted = true;
				const current = expectOk(await b.files.read(path));
				const before = current === undefined ? null : new Uint8Array(await current.content.arrayBuffer());
				let outside: string | Uint8Array;
				switch (mode) {
					case 'presentation': outside = decoder.decode(before ?? new Uint8Array()).replace(/^(\uFEFF?---\r?\n|---\r?\n)/, '$1# outside presentation\n'); break;
					case 'malformed': outside = '---\ntitle: [broken\n---\noutside body\n'; break;
					case 'unclosed': outside = '---\ntitle: unfinished\noutside\n'; break;
					case 'binary': outside = new Uint8Array([255, 0, 2]); break;
					default: outside = (before === null ? '' : decoder.decode(before)) + 'outside\n';
				}
				expectOk(await b.files.write(path, before, outside));
			}
			const saved = await publish(input);
			if (!saved) stalePublications++;
			return saved;
		};
		files.write = async (...args) => {
			const result = await write(...args);
			if (gateFirst) {
				gateFirst = false; attempted.resolve(); await receipt.promise;
			}
			return result;
		};
		const first = edit.save();
		const delayed = await Promise.race([attempted.promise.then(() => true), first.then(() => false)]);
		events.push({ stage: 'during', delayed, state: snapshot(edit) });
		for (const step of tail) events.push({ stage: 'tail', step, accepted: action(edit, step).error?.name, state: snapshot(edit) });
		receipt.resolve(); await first;
		events.push({ stage: 'receipt', state: snapshot(edit) });
		armed = false;
		// A second real attempt exercises remaining intent after both outcomes.
		await edit.save();
		events.push({ stage: 'retry', state: snapshot(edit) });
		if (edit.getPending()?.error !== undefined) {
			const held = snapshot(edit);
			const current = expectOk(await b.files.read(path));
			expectOk(await b.files.write(path, current === undefined ? null : new Uint8Array(await current.content.arrayBuffer()), repair));
			expectOk(await edit.read());
			await edit.save();
			if (edit.getPending() === undefined) successfulRepairs++;
			events.push({ stage: 'recovery', held, state: snapshot(edit) });
		}
		const final = expectOk(await b.files.read(path));
		const bytes = final === undefined ? undefined : new Uint8Array(await final.content.arrayBuffer());
		bytesChecked += bytes?.length ?? 0;
		events.push({ stage: 'final', state: snapshot(edit), table: folder.tables.notes.edit('a').getMarkdown(), bytes: bytes === undefined ? undefined : [...bytes] });
		return { events, stalePublications, injectedFailures, bytesChecked, exactHeaderChecks, successfulRepairs };
	} finally {
		receipt.resolve(); armed = false; files.write = write;
		await folder.close(); b.close();
	}
}

let scenarios = 0;
let mismatches = 0;
let stalePublications = 0;
let injectedFailures = 0;
let bytesChecked = 0;
let exactHeaderChecks = 0;
let recoveries = 0;
let successfulRepairs = 0;
const differences: unknown[] = [];
const encode = (value: unknown) => JSON.stringify(value, (_key, item) => item === undefined ? { unavailable: true } : item);
for (const [fixture, original] of fixtures.entries()) for (const prefix of prefixes) for (const tail of tails) for (const mode of modes) {
	const expected = await run(reference, original, prefix, tail, mode);
	const actual = await run(candidate, original, prefix, tail, mode);
	scenarios++;
	stalePublications += actual.stalePublications;
	injectedFailures += actual.injectedFailures;
	bytesChecked += actual.bytesChecked;
	exactHeaderChecks += actual.exactHeaderChecks;
	recoveries += actual.events.filter(event => (event as { stage: string }).stage === 'recovery').length;
	successfulRepairs += actual.successfulRepairs;
	if (encode(expected.events) !== encode(actual.events) || expected.stalePublications !== actual.stalePublications || expected.injectedFailures !== actual.injectedFailures) {
		mismatches++;
		if (differences.length < 3) differences.push({ fixture, prefix, tail, mode, expected, actual });
	}
}
console.log(JSON.stringify({ scenarios, mismatches, stalePublications, injectedFailures, bytesChecked, exactHeaderChecks, recoveries, successfulRepairs, differences }, null, 2));
if (mismatches > 0 || stalePublications === 0 || injectedFailures === 0 || recoveries === 0) process.exitCode = 1;
