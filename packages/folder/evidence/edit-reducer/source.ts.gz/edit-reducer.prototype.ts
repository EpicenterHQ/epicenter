/**
 * Throwaway reducer experiment. Run: bun src/edit-reducer.prototype.ts
 *
 * Does one bounded normal form plus two continuations of an in-flight save
 * preserve a command-history oracle across success and failure? This models
 * semantic values in valid Markdown, not exact YAML presentation or malformed
 * source recovery. The oracle derives each unit retrospectively from accepted
 * command occurrences; the candidate updates sparse state incrementally.
 */
import { diffArrays } from 'diff';
import { mergeLinesWith } from './shared/content/merge-lines.js';

type Document = { fields: Record<string, string>; body: string };
type Command = {
	id: number;
	kind: 'fields' | 'body' | 'source';
	before: Document;
	after: Document;
	keys: string[];
};
type Plan = {
	fields: Map<string, { base: string | undefined; value: string | undefined; assigned: boolean; id: number }>;
	body?: { base: string; value: string };
};

const initial = (): Document => ({ fields: { title: 'Old', tag: 'before' }, body: 'one\ntwo\nthree\n' });
const empty = (): Plan => ({ fields: new Map() });
const copy = (doc: Document): Document => structuredClone(doc);
const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);
let serial = 0;

function command(doc: Document, action: number): Command {
	const before = copy(doc);
	const after = copy(doc);
	const id = ++serial;
	switch (action) {
		case 0: after.fields.title = 'Mine'; break;
		case 1: after.fields.title = 'Old'; break;
		case 2: delete after.fields.tag; break;
		case 3: after.fields.tag = 'mine'; break;
		case 4: after.body = 'one\ntwo\nTHREE\n'; break;
		case 5: after.body = initial().body; break;
		case 6: after.fields.title = 'Old'; after.body += 'local\n'; break;
		case 7: after.fields.title = 'Source'; after.fields.tag = 'source'; break;
		case 8: after.body += 'source\n'; break;
		case 9: after.fields.title = doc.fields.title ?? 'Old'; break;
	}
	const kind = action >= 6 && action <= 8 ? 'source' : action >= 4 && action <= 5 ? 'body' : 'fields';
	const keys = kind === 'source'
		? [...new Set([...Object.keys(before.fields), ...Object.keys(after.fields)])].filter(key => before.fields[key] !== after.fields[key])
		: kind === 'fields' ? [action === 2 || action === 3 ? 'tag' : 'title'] : [];
	return { id, kind, before, after, keys };
}

/** Candidate: at most one entry per field and one body witness per branch. */
function append(plan: Plan, cmd: Command) {
	for (const key of cmd.keys) {
		plan.fields.set(key, {
			base: plan.fields.get(key)?.base ?? (plan.fields.has(key) ? undefined : cmd.before.fields[key]),
			value: cmd.after.fields[key],
			assigned: cmd.kind === 'fields',
			id: cmd.id,
		});
	}
	if (cmd.kind === 'body' || cmd.before.body !== cmd.after.body) {
		plan.body = { base: plan.body?.base ?? cmd.before.body, value: cmd.after.body };
	}
}

/** Oracle: query the complete accepted history afresh for each unit. */
function history(commands: readonly Command[]): Plan {
	const fields = new Map<string, Plan['fields'] extends Map<string, infer T> ? T : never>();
	for (const key of new Set(commands.flatMap(cmd => cmd.keys))) {
		const affecting = commands.filter(cmd => cmd.keys.includes(key));
		const first = affecting[0]!;
		const last = affecting.at(-1)!;
		fields.set(key, { base: first.before.fields[key], value: last.after.fields[key], assigned: last.kind === 'fields', id: last.id });
	}
	const bodies = commands.filter(cmd => cmd.kind === 'body' || cmd.before.body !== cmd.after.body);
	return {
		fields,
		body: bodies.length === 0 ? undefined : { base: bodies[0]!.before.body, value: bodies.at(-1)!.after.body },
	};
}

function save(current: Document, plan: Plan): Document {
	const result = copy(current);
	for (const [key, edit] of plan.fields) {
		if (!edit.assigned && edit.value === edit.base) continue;
		if (edit.value === undefined) delete result.fields[key];
		else result.fields[key] = edit.value;
	}
	if (plan.body !== undefined) {
		result.body = mergeLinesWith(diffArrays, { base: plan.body.base, current: result.body, change: plan.body.value }).content;
	}
	return result;
}

function comparable(plan: Plan) {
	return { fields: [...plan.fields].sort(([a], [b]) => a.localeCompare(b)), body: plan.body };
}

let cases = 0;
let mismatches = 0;
let maxEntries = 0;
const failures: unknown[] = [];
const illustrations: unknown[] = [];
function compare(candidate: Plan, expected: Plan, stored: Document, label: unknown) {
	cases++;
	maxEntries = Math.max(maxEntries, candidate.fields.size + Number(candidate.body !== undefined));
	if (!same(comparable(candidate), comparable(expected)) || !same(save(stored, candidate), save(stored, expected))) {
		mismatches++;
		if (failures.length < 3) failures.push({ label, candidate: comparable(candidate), expected: comparable(expected) });
	}
}

const tails: number[][] = [[]];
for (let depth = 0, layer: number[][] = [[]]; depth < 3; depth++) {
	layer = layer.flatMap(prefix => Array.from({ length: 10 }, (_, next) => [...prefix, next]));
	tails.push(...layer);
}

// Every pair of prefix commands, zero through three tail commands, success
// and failure, and outside changes to fields and independent body regions.
for (let a = 0; a < 10; a++) for (let b = 0; b < 10; b++) {
	for (const tail of tails) for (const succeeded of [false, true]) {
		let shown = initial();
		const prefix: Command[] = [];
		const all = empty();
		for (const action of [a, b]) {
			const cmd = command(shown, action);
			prefix.push(cmd); append(all, cmd); shown = cmd.after;
		}
		const submitted = history(prefix);
		let stored: Document = { fields: { title: 'Outside', tag: 'outside' }, body: 'ONE\ntwo\nthree\n' };
		compare(all, submitted, stored, { prefix: [a, b], stage: 'submission' });
		if (succeeded) stored = save(stored, submitted);
		// A second outside edit lands after commit but before acknowledgment.
		stored.fields.tag = 'later outside';
		stored.body = stored.body.replace('two\n', 'TWO\n');
		const open = empty();
		const later: Command[] = [];
		for (const action of tail) {
			const cmd = command(shown, action);
			later.push(cmd); append(all, cmd); append(open, cmd); shown = cmd.after;
		}
		const candidate = succeeded ? open : all;
		const expected = history(succeeded ? later : [...prefix, ...later]);
		compare(candidate, expected, stored, { prefix: [a, b], tail, succeeded });
		if (a === 0 && b === 9 && same(tail, [6])) {
			illustrations.push({ firstSave: succeeded ? 'success' : 'failure', remaining: comparable(candidate), final: save(stored, candidate) });
		}
		// Failed attempts do not manufacture another history generation. After
		// two failures, retry the same bounded continuation over fresh storage.
		if (!succeeded) {
			stored.fields.tag = 'after repeated failure';
			compare(candidate, expected, stored, { prefix: [a, b], tail, repeatedFailure: true });
		}
		// Compose another save boundary, including new edits after a failed
		// prefix. Cover both outcomes and source/form crossings in both orders.
		if (tail.length <= 2) for (const [beforeSave, duringSave] of [[6, 0], [0, 6], [4, 5], [2, 9]] as const) {
			for (const secondSucceeded of [false, true]) {
				const carried = succeeded ? later : [...prefix, ...later];
				const next = structuredClone(candidate);
				const prior = command(save(stored, candidate), beforeSave);
				append(next, prior);
				const nextHistory = [...carried, prior];
				const current = secondSucceeded ? save(stored, history(nextHistory)) : copy(stored);
				current.fields.title = 'outside after second attempt';
				const last = command(prior.after, duringSave);
				const secondOpen = empty();
				append(next, last); append(secondOpen, last);
				compare(
					secondSucceeded ? secondOpen : next,
					history(secondSucceeded ? [last] : [...nextHistory, last]),
					current,
					{ prefix: [a, b], tail, succeeded, beforeSave, duringSave, secondSucceeded },
				);
			}
		}
	}
}

// A long in-flight tail must grow the reference history, not candidate state.
const longHistory: Command[] = [];
const longAll = empty();
const longOpen = empty();
let longShown = initial();
const longPrefix = command(longShown, 0);
append(longAll, longPrefix); longShown = longPrefix.after;
for (let index = 0; index < 20_000; index++) {
	const cmd = command(longShown, index % 10);
	longHistory.push(cmd); append(longAll, cmd); append(longOpen, cmd); longShown = cmd.after;
}
for (const succeeded of [false, true]) {
	compare(succeeded ? longOpen : longAll, history(succeeded ? longHistory : [longPrefix, ...longHistory]), initial(), { longTail: longHistory.length, succeeded });
}

// Negative control: equality-based acknowledgment must lose the newer command.
const first = command(initial(), 0);
const repeated = command(first.after, 0);
const pending = history([repeated]);
const dropped = empty();
const outside = initial(); outside.fields.title = 'Outside';
const equalityControlDetected = !same(save(outside, dropped), save(outside, pending));

// Negative control: unconditional rebasing to the stored result loses an
// unseen independent body region in a later source replacement.
const sentBody = initial().body;
const storedBody = sentBody.replace('two\n', 'outside\n');
const laterBody = sentBody + 'local\n';
const wrongBody = mergeLinesWith(diffArrays, { base: storedBody, current: storedBody, change: laterBody }).content;
const rightBody = mergeLinesWith(diffArrays, { base: sentBody, current: storedBody, change: laterBody }).content;
const witnessControlDetected = wrongBody !== rightBody && rightBody.includes('outside\n');

const report = { cases, mismatches, maxEntriesPerBranch: maxEntries, branchesDuringSave: 2, longTailCommands: longHistory.length, equalityControlDetected, witnessControlDetected, illustrations, failures };
console.log(JSON.stringify(report, null, 2));
if (mismatches > 0 || !equalityControlDetected || !witnessControlDetected) process.exitCode = 1;
