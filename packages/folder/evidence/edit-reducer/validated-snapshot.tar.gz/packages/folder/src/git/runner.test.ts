/**
 * Pass Runner and Commit Message Tests
 *
 * The runner orders a folder's Git passes: one at a time, entered by
 * `attempt` for work nobody waits on, by `request` for a caller that does, and
 * by `follow` for callers content to share the next pass. Commit subjects are
 * derived from captured tree changes (ADR-0469).
 *
 * Key behaviors:
 * - `attempt` starts a pass only when nothing runs or waits; otherwise it does
 *   nothing and never runs later
 * - `request` waits for the passes ahead and runs its own, in arrival order
 * - `follow` shares one pass that has not started; nobody joins a running one
 * - `close` aborts the active pass, waits for it, and tells waiting callers
 *   and later ones that the runner closed
 * - A throwing pass becomes a result and the runner keeps working
 * - Subjects name one path or count several, escape control characters, and
 *   fall back past 72 characters; user messages must be nonempty text
 *
 * See also:
 * - `history.test.ts` for close ordering across commit and push runners
 */
import { describe, expect, test } from 'bun:test';
import { commitSubject, escapePath, messageProblem } from './messages.js';
import { createPassRunner } from './runner.js';

function gate() {
	let open!: () => void;
	const opened = new Promise<void>((resolve) => {
		open = resolve;
	});
	return { opened, open };
}

function counting({ obeysAbort = true } = {}) {
	const gates: ReturnType<typeof gate>[] = [];
	let starts = 0;
	let changes = 0;
	const runner = createPassRunner<string>({
		async run(signal) {
			const index = starts++;
			const current = gate();
			gates.push(current);
			await Promise.race([
				current.opened,
				new Promise<void>((resolve) => {
					if (obeysAbort) signal.addEventListener('abort', () => resolve());
				}),
			]);
			return obeysAbort && signal.aborted
				? `aborted ${index}`
				: `pass ${index}`;
		},
		failed: (cause) => `failed ${String(cause)}`,
		closed: () => 'closed',
		onChange: () => changes++,
	});
	return { runner, gates, starts: () => starts, changes: () => changes };
}

describe('createPassRunner', () => {
	test('an attempt starts a pass when idle; one made during a pass does nothing and never runs later', async () => {
		const { runner, gates, starts, changes } = counting();
		const first = runner.attempt();
		await Bun.sleep(0);
		expect(starts()).toBe(1);
		expect(runner.active).toBe(true);
		const before = changes();
		expect(runner.attempt()).toBeUndefined();
		expect(runner.attempt()).toBeUndefined();
		// A skipped attempt changed nothing an observer could see.
		expect(changes()).toBe(before);
		gates[0]!.open();
		expect(await first).toBe('pass 0');
		expect(runner.active).toBe(false);
		await Bun.sleep(5);
		expect(starts()).toBe(1);
		const next = runner.attempt();
		await Bun.sleep(0);
		gates[1]!.open();
		expect(await next).toBe('pass 1');
	});

	test('requests wait for the passes ahead and each runs its own, in order', async () => {
		const { runner, gates, starts } = counting();
		const first = runner.request();
		const second = runner.request();
		const third = runner.request();
		await Bun.sleep(0);
		expect(starts()).toBe(1);
		gates[0]!.open();
		expect(await first).toBe('pass 0');
		await Bun.sleep(0);
		expect(starts()).toBe(2);
		gates[1]!.open();
		expect(await second).toBe('pass 1');
		await Bun.sleep(0);
		gates[2]!.open();
		expect(await third).toBe('pass 2');
		expect(starts()).toBe(3);
	});

	test('an attempt does not start between a finished pass and a caller already waiting', async () => {
		const { runner, gates, starts } = counting();
		const first = runner.request();
		const waiting = runner.request();
		await Bun.sleep(0);
		gates[0]!.open();
		await first;
		// The pass ended this instant; the waiter's turn has not begun yet.
		expect(runner.attempt()).toBeUndefined();
		await Bun.sleep(0);
		gates[1]!.open();
		expect(await waiting).toBe('pass 1');
		expect(starts()).toBe(2);
	});

	test('followers share one pass that starts after they asked and never join a running one', async () => {
		const { runner, gates, starts } = counting();
		// Asked together while idle: one pass serves both.
		const a = runner.follow();
		const b = runner.follow();
		expect(b).toBe(a);
		await Bun.sleep(0);
		expect(starts()).toBe(1);

		// Asked while that pass runs: one more pass, shared, not the running one.
		const c = runner.follow();
		const d = runner.follow();
		expect(c).not.toBe(a);
		expect(d).toBe(c);
		await Bun.sleep(5);
		expect(starts()).toBe(1);
		gates[0]!.open();
		expect(await a).toBe('pass 0');
		await Bun.sleep(0);
		expect(starts()).toBe(2);

		// Asked while the follower runs: the next pass, not this one.
		const e = runner.follow();
		expect(e).not.toBe(c);
		gates[1]!.open();
		expect(await c).toBe('pass 1');
		await Bun.sleep(0);
		gates[2]!.open();
		expect(await e).toBe('pass 2');
		expect(starts()).toBe(3);
	});

	test('close tells a waiting follower that the runner closed', async () => {
		const { runner, starts } = counting();
		const first = runner.request();
		const follower = runner.follow();
		await Bun.sleep(0);
		await runner.close();
		expect(await first).toBe('aborted 0');
		expect(await follower).toBe('closed');
		expect(await runner.follow()).toBe('closed');
		expect(starts()).toBe(1);
	});

	test('close aborts the active pass, waits for it, and tells waiting and later callers it closed', async () => {
		const { runner, starts } = counting();
		const first = runner.request();
		const waiting = runner.request();
		await Bun.sleep(0);
		await runner.close();
		expect(await first).toBe('aborted 0');
		expect(await waiting).toBe('closed');
		expect(runner.active).toBe(false);
		expect(await runner.request()).toBe('closed');
		expect(runner.attempt()).toBeUndefined();
		expect(starts()).toBe(1);
	});

	test('close waits for a pass that ignores its signal, and that pass reports what it really did', async () => {
		const { runner, gates } = counting({ obeysAbort: false });
		const first = runner.request();
		await Bun.sleep(0);
		let closed = false;
		const closing = runner.close().then(() => {
			closed = true;
		});
		expect(await runner.request()).toBe('closed');
		await Bun.sleep(5);
		expect(closed).toBe(false);
		gates[0]!.open();
		await closing;
		expect(await first).toBe('pass 0');
	});

	test('a throwing pass becomes a result and the runner keeps working', async () => {
		let calls = 0;
		const runner = createPassRunner<string>({
			async run() {
				calls++;
				if (calls === 1) throw new Error('boom');
				return 'ok';
			},
			failed: (cause) => `failed: ${(cause as Error).message}`,
			closed: () => 'closed',
		});
		expect(await runner.request()).toBe('failed: boom');
		expect(await runner.request()).toBe('ok');
	});
});

describe('commit subjects', () => {
	test('name one path by its change and count several', () => {
		expect(commitSubject([{ path: 'todos/a.md', kind: 'add' }])).toBe(
			'Add todos/a.md',
		);
		expect(commitSubject([{ path: 'todos/a.md', kind: 'modify' }])).toBe(
			'Update todos/a.md',
		);
		expect(commitSubject([{ path: 'todos/a.md', kind: 'delete' }])).toBe(
			'Delete todos/a.md',
		);
		expect(
			commitSubject([
				{ path: 'todos/a.md', kind: 'delete' },
				{ path: 'todos/b.md', kind: 'add' },
			]),
		).toBe('Update 2 files');
		expect(commitSubject([])).toBeUndefined();
	});

	test('escape control characters and fall back past 72 characters', () => {
		expect(escapePath('a\nb\\c')).toBe('a\\x0ab\\\\c');
		expect(commitSubject([{ path: 'x\ny.md', kind: 'add' }])).toBe(
			'Add x\\x0ay.md',
		);
		expect(
			commitSubject([{ path: `${'a'.repeat(70)}.md`, kind: 'modify' }]),
		).toBe('Update 1 file');
	});

	test('user messages must be nonempty and free of control characters', () => {
		expect(messageProblem('  ')).toBeDefined();
		expect(messageProblem('ok\x00')).toBeDefined();
		expect(messageProblem('Fix typo\n\nDetails')).toBeUndefined();
	});
});
