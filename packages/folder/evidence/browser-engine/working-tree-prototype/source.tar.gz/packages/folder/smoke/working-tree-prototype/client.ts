/** Scratch benchmark client. No app data, public Folder changes, or Git traffic. */
import { unwrap } from 'wellcrafted/result';
import { changeSnapshot } from '../../src/browser/git/snapshot.js';
import { openRepository } from '../../src/browser/repository.js';
import {
	type GitObject,
	hashObject,
	writeCommit,
} from '../../src/git/raw-objects.js';
import type { FileContent } from '../../src/shared/merge.js';
import { openWorkingTree } from './store.js';

type Model = 'overlay' | 'working-tree' | 'working-tree-key-gc';
type Fixture = {
	rows: number;
	layout: 'wide' | 'sharded';
	checkpoint: boolean;
	threshold: number;
};
let model: Model;
let fixture: Fixture;
let overlay: Awaited<ReturnType<typeof openRepository>> | undefined;
let tree: Awaited<ReturnType<typeof openWorkingTree>> | undefined;
let drafts = new Map<string, FileContent>();
const encoder = new TextEncoder();
const pathOf = (index: number) =>
	fixture.layout === 'wide'
		? `notes/${String(index).padStart(4, '0')}.md`
		: `archive/${String(index % 40).padStart(3, '0')}/${String(index).padStart(4, '0')}.md`;
const textOf = (index: number) =>
	`---\ntitle: Note ${index}\na: 0\nb: 0\n---\n${'x'.repeat(5000)}\n`;

async function write(
	path: string,
	from: FileContent | null,
	change: FileContent,
) {
	if (model !== 'overlay') return tree!.save(path, from, change);
	const start = performance.now();
	unwrap(await overlay!.files.write(path, from, change));
	return {
		ms: performance.now() - start,
		retries: 0,
		gc: null,
		phases: null,
		writtenBytes:
			typeof change === 'string'
				? encoder.encode(change).length
				: change.byteLength,
	};
}

export const client = {
	async open(options: { model: Model; id: string; fixture: Fixture }) {
		overlay?.close();
		tree?.close();
		overlay = undefined;
		tree = undefined;
		model = options.model;
		fixture = options.fixture;
		drafts = new Map();
		if (model === 'overlay')
			overlay = await openRepository(`PROTOTYPE-wipe-me-${options.id}`);
		else
			tree = await openWorkingTree(
				`PROTOTYPE-wipe-me-tree-${options.id}`,
				fixture.threshold,
				model === 'working-tree-key-gc',
			);
	},
	async seed() {
		const files = new Map(
			Array.from({ length: fixture.rows }, (_, index) => [
				pathOf(index),
				textOf(index),
			]),
		);
		if (tree !== undefined) {
			await tree.seed(files);
			if (fixture.checkpoint) await tree.checkpoint('received');
		} else if (!fixture.checkpoint) {
			if (!(await overlay!.storage.publish({ revision: 0, edits: files })))
				throw new Error('Seed raced');
		} else {
			const candidate = await changeSnapshot({
				root: null,
				edits: files,
				read: async () => {
					throw new Error('Fresh seed');
				},
			});
			const commit: GitObject = {
				type: 'commit',
				bytes: writeCommit({
					tree: candidate.tree,
					parents: [],
					author: {
						name: 'Prototype',
						email: 'prototype@example.invalid',
						timestamp: 1,
					},
					message: 'Simulated incorporated checkpoint',
				}),
			};
			const oid = await hashObject(commit);
			candidate.objects.set(oid, commit);
			if (
				!(await overlay!.storage.publish({
					revision: 0,
					objects: candidate.objects,
					refs: { remoteBase: oid, pendingCommit: null },
				}))
			)
				throw new Error('Seed raced');
		}
	},
	async edit(
		count: number,
		spread = false,
		field: 'a' | 'b' = 'a',
		offset = 0,
	) {
		const samples = [];
		for (let i = 0; i < count; i++) {
			const index = spread ? i % fixture.rows : 0;
			const path = pathOf(index);
			const from = drafts.get(path) ?? textOf(index);
			if (typeof from !== 'string') throw new Error('Not a note');
			const next = from.replace(
				new RegExp(`^${field}: .*`, 'm'),
				`${field}: ${offset + i + 1}`,
			);
			samples.push(await write(path, from, next));
			drafts.set(path, next);
		}
		return samples;
	},
	async binary(count: number, overwrite: boolean, bytes = 2 * 1024 * 1024) {
		const samples = [];
		for (let i = 0; i < count; i++) {
			const path = `recordings/${overwrite ? 'one' : i}.wav`;
			const content = new Uint8Array(bytes).fill((i + 1) % 255);
			samples.push(await write(path, drafts.get(path) ?? null, content));
			drafts.set(path, content);
		}
		return samples;
	},
	async reads(count: number) {
		const samples = [];
		for (let i = 0; i < count; i++) {
			const start = performance.now();
			await client.text(pathOf(0));
			samples.push(performance.now() - start);
		}
		return samples;
	},
	async lists(count: number) {
		const samples = [];
		for (let i = 0; i < count; i++) {
			const start = performance.now();
			const prefix = fixture.layout === 'wide' ? 'notes/' : 'archive/';
			const paths =
				tree !== undefined
					? await tree.list(prefix)
					: unwrap(await overlay!.files.list(prefix));
			if (paths.length !== fixture.rows) throw new Error('List lost a note');
			samples.push(performance.now() - start);
		}
		return samples;
	},
	async text(path = pathOf(0)) {
		if (tree !== undefined) {
			const bytes = await tree.read(path);
			return bytes === null ? null : new Blob([new Uint8Array(bytes)]).text();
		}
		return (
			(await unwrap(await overlay!.files.read(path))?.content.text()) ?? null
		);
	},
	async stats() {
		if (tree !== undefined) return tree.stats();
		const snapshot = await overlay!.storage.capture();
		return {
			state: snapshot.state,
			objects: snapshot.objects.size,
			bytes:
				[...snapshot.objects.values()].reduce(
					(sum, object) => sum + object.bytes.byteLength,
					0,
				) +
				[...snapshot.edits.values()].reduce(
					(sum, value) =>
						sum +
						(typeof value === 'string'
							? encoder.encode(value).length
							: (value?.byteLength ?? 0)),
					0,
				),
		};
	},
	async collect() {
		if (tree === undefined)
			throw new Error('Only the prototype collects offline');
		return tree.collect();
	},
	async checkpoints() {
		if (tree === undefined) throw new Error('Only the prototype');
		const received = await tree.checkpoint('received');
		await client.edit(1, false, 'a', 7000);
		const sending = await tree.checkpoint('sending');
		return { received, sending };
	},
	async acknowledge(received: string, sending: string) {
		return tree!.acknowledge(received, sending);
	},
	async binaryMarker(path: string) {
		const bytes =
			tree !== undefined
				? await tree.read(path)
				: new Uint8Array(
						await unwrap(
							await overlay!.files.read(path),
						)!.content.arrayBuffer(),
					);
		return bytes === null
			? null
			: { length: bytes.length, first: bytes[0], last: bytes.at(-1) };
	},
	async values() {
		const text = await client.text();
		return {
			a: Number(text?.match(/^a: (\d+)/m)?.[1]),
			b: Number(text?.match(/^b: (\d+)/m)?.[1]),
			bodyIntact: text?.includes('x'.repeat(5000)),
		};
	},
	close() {
		overlay?.close();
		tree?.close();
	},
};

declare global {
	var workingTreePrototype: typeof client;
}
globalThis.workingTreePrototype = client;
