/**
 * bun packages/folder/smoke/working-tree-prototype/run.ts --output <report.json>
 * Disposable real-browser experiment. No app profiles, migration, or network sync.
 */
import { mkdtemp, rm } from 'node:fs/promises';
import { cpus, tmpdir } from 'node:os';
import { basename, join } from 'node:path';
import { parseArgs } from 'node:util';
import { type BrowserContext, chromium, firefox, webkit } from 'playwright';
import type {} from './client.js';

const { values } = parseArgs({
	args: Bun.argv.slice(2),
	options: {
		browser: { type: 'string', default: 'all' },
		trials: { type: 'string', default: '2' },
		saves: { type: 'string', default: '360' },
		output: { type: 'string' },
	},
});
const trials = Number(values.trials);
const saves = Number(values.saves);
if (
	!['all', 'chromium', 'webkit', 'firefox'].includes(values.browser) ||
	!Number.isInteger(trials) ||
	trials < 1 ||
	!Number.isInteger(saves) ||
	saves < 1
)
	throw new Error(
		'Choose an installed browser (or all), and positive integer trials/saves.',
	);
const bundle = await Bun.build({
	entrypoints: [join(import.meta.dir, 'client.ts')],
	target: 'browser',
});
if (!bundle.success)
	throw new AggregateError(bundle.logs, 'Prototype build failed');
const script = await bundle.outputs[0]!.text();
const server = Bun.serve({
	hostname: '127.0.0.1',
	port: 0,
	fetch(input) {
		return new URL(input.url).pathname === '/client.js'
			? new Response(script, { headers: { 'content-type': 'text/javascript' } })
			: new Response(
					'<!doctype html><title>Working-tree prototype</title><script type="module" src="/client.js"></script>',
					{ headers: { 'content-type': 'text/html' } },
				);
	},
});
const summary = (values: number[]) => {
	const sorted = [...values].sort((a, b) => a - b);
	const at = (q: number) =>
		sorted[Math.min(sorted.length - 1, Math.ceil(sorted.length * q) - 1)] ?? 0;
	return {
		count: sorted.length,
		p50: at(0.5),
		p95: at(0.95),
		p99: at(0.99),
		max: sorted.at(-1) ?? 0,
	};
};
function check(condition: unknown, message: string): asserts condition {
	if (!condition) throw new Error(message);
}
async function pageIn(context: BrowserContext) {
	const page = await context.newPage();
	page.setDefaultTimeout(180_000);
	page.on('pageerror', (error) =>
		console.error('Prototype page:', error.message),
	);
	await page.goto(server.url.href);
	await page.waitForFunction(
		() => globalThis.workingTreePrototype !== undefined,
	);
	return page;
}
const results = [];
const checks = [];
try {
	for (const [browser, browserType] of Object.entries({
		chromium,
		webkit,
		firefox,
	})) {
		if (values.browser !== 'all' && values.browser !== browser) continue;
		const profile = await mkdtemp(
			join(tmpdir(), `epicenter-PROTOTYPE-wipe-me-${browser}-`),
		);
		const launch = () =>
			browserType.launchPersistentContext(profile, { headless: true });
		let context = await launch();
		try {
			for (let trial = 0; trial < trials; trial++) {
				const cases = [
					{
						name: 'small-local',
						rows: 50,
						layout: 'wide' as const,
						checkpoint: false,
						count: 80,
						operation: 'edit',
					},
					{
						name: 'wide-local',
						rows: 2000,
						layout: 'wide' as const,
						checkpoint: false,
						count: saves,
						operation: 'edit',
					},
					{
						name: 'wide-checkpoint',
						rows: 2000,
						layout: 'wide' as const,
						checkpoint: true,
						count: saves,
						operation: 'edit',
					},
					{
						name: 'sharded-local',
						rows: 2000,
						layout: 'sharded' as const,
						checkpoint: false,
						count: 160,
						operation: 'edit',
					},
					{
						name: 'spread-local',
						rows: 2000,
						layout: 'wide' as const,
						checkpoint: false,
						count: 160,
						operation: 'spread',
					},
					{
						name: 'binary-add',
						rows: 50,
						layout: 'wide' as const,
						checkpoint: false,
						count: 8,
						operation: 'binary-add',
					},
					{
						name: 'binary-overwrite',
						rows: 50,
						layout: 'wide' as const,
						checkpoint: false,
						count: 12,
						operation: 'binary-overwrite',
					},
				];
				for (const scenario of cases)
					for (const model of trial % 2 === 0
						? (['overlay', 'working-tree', 'working-tree-key-gc'] as const)
						: (['working-tree-key-gc', 'working-tree', 'overlay'] as const)) {
						const page = await pageIn(context);
						const fixture = {
							rows: scenario.rows,
							layout: scenario.layout,
							checkpoint: scenario.checkpoint,
							threshold: 8 * 1024 * 1024,
						};
						const options = {
							model,
							id: `${browser}-${trial}-${scenario.name}-${model}`,
							fixture,
						};
						await page.evaluate(
							(options) => workingTreePrototype.open(options),
							options,
						);
						await page.evaluate(() => workingTreePrototype.seed());
						const before = await page.evaluate(() =>
							workingTreePrototype.stats(),
						);
						await page.evaluate(() => workingTreePrototype.edit(5));
						const readBefore = await page.evaluate(() =>
							workingTreePrototype.reads(20),
						);
						const lists = await page.evaluate(() =>
							workingTreePrototype.lists(5),
						);
						const samples = await page.evaluate(
							async ({ operation, count }) => {
								if (operation === 'binary-add')
									return workingTreePrototype.binary(count, false);
								if (operation === 'binary-overwrite')
									return workingTreePrototype.binary(count, true);
								return workingTreePrototype.edit(
									count,
									operation === 'spread',
									'a',
									100,
								);
							},
							{ operation: scenario.operation, count: scenario.count },
						);
						const readAfter = await page.evaluate(() =>
							workingTreePrototype.reads(20),
						);
						const after = await page.evaluate(() =>
							workingTreePrototype.stats(),
						);
						const forcedCollection =
							model !== 'overlay'
								? await page.evaluate(() => workingTreePrototype.collect())
								: null;
						const afterCollection = await page.evaluate(() =>
							workingTreePrototype.stats(),
						);
						const state = await page.evaluate(() =>
							workingTreePrototype.values(),
						);
						check(state.bodyIntact, `${browser}/${scenario.name} damaged body`);
						if (scenario.operation === 'edit')
							check(state.a === scenario.count + 100, 'Saved field missing');
						if (scenario.operation.startsWith('binary')) {
							const path = `recordings/${scenario.operation === 'binary-overwrite' ? 'one' : scenario.count - 1}.wav`;
							const marker = await page.evaluate(
								(path) => workingTreePrototype.binaryMarker(path),
								path,
							);
							check(
								marker?.length === 2 * 1024 * 1024 &&
									marker.first === scenario.count &&
									marker.last === scenario.count,
								'Binary bytes changed',
							);
						}
						const gc = samples.flatMap((sample) =>
							sample.gc === null ? [] : [sample.gc],
						);
						const report = {
							browser,
							version: context.browser()?.version(),
							trial,
							scenario: scenario.name,
							model,
							fixture,
							saveMs: summary(samples.map((sample) => sample.ms)),
							saveWithoutGcMs: summary(
								samples
									.filter((sample) => sample.gc === null)
									.map((sample) => sample.ms),
							),
							saveWithGcMs: summary(
								samples
									.filter((sample) => sample.gc !== null)
									.map((sample) => sample.ms),
							),
							readBeforeMs: summary(readBefore),
							readAfterMs: summary(readAfter),
							listMs: summary(lists),
							gcMs: summary(gc.map((entry) => entry.ms)),
							gc,
							forcedCollection,
							before,
							after,
							afterCollection,
							retries: samples.reduce((sum, sample) => sum + sample.retries, 0),
							writtenBytes: samples.reduce(
								(sum, sample) => sum + sample.writtenBytes,
								0,
							),
							samples,
							readBefore,
							readAfter,
							lists,
						};
						results.push(report);
						console.log(
							`${browser} trial ${trial + 1} ${scenario.name} ${model}: save p95 ${report.saveMs.p95.toFixed(1)}ms max ${report.saveMs.max.toFixed(1)}ms; GC ${gc.length}/${report.gcMs.max.toFixed(1)}ms`,
						);
						await page.evaluate(() => workingTreePrototype.close());
						await page.close();
					}
			}

			// Keep three roots alive while tabs save and collect; then reopen the profile.
			const options = {
				model: 'working-tree-key-gc' as const,
				id: `${browser}-race`,
				fixture: {
					rows: 2000,
					layout: 'wide' as const,
					checkpoint: false,
					threshold: 1024 * 1024,
				},
			};
			const first = await pageIn(context);
			await first.evaluate(
				(options) => workingTreePrototype.open(options),
				options,
			);
			await first.evaluate(() => workingTreePrototype.seed());
			const refs = await first.evaluate(() =>
				workingTreePrototype.checkpoints(),
			);
			const second = await pageIn(context);
			await second.evaluate(
				(options) => workingTreePrototype.open(options),
				options,
			);
			const [a, b, collections] = await Promise.all([
				first.evaluate(() => workingTreePrototype.edit(60, false, 'a', 1000)),
				second.evaluate(() => workingTreePrototype.edit(60, false, 'b', 2000)),
				second.evaluate(async () => {
					const out = [];
					for (let i = 0; i < 3; i++)
						out.push(await workingTreePrototype.collect());
					return out;
				}),
			]);
			const beforeAck = await first.evaluate(() =>
				workingTreePrototype.stats(),
			);
			check(
				beforeAck.state.remoteBase === refs.received &&
					beforeAck.state.pendingCommit === refs.sending,
				'Collection changed checkpoint refs',
			);
			check(
				await first.evaluate(
					(refs) =>
						workingTreePrototype.acknowledge(refs.received, refs.sending),
					refs,
				),
				'Acknowledgement failed',
			);
			await first.evaluate(() => workingTreePrototype.collect());
			const final = await first.evaluate(() => workingTreePrototype.values());
			check(
				final.a === 1060 && final.b === 2060 && final.bodyIntact,
				'Concurrent save or acknowledgement lost work',
			);
			const beforeReopen = await first.evaluate(() =>
				workingTreePrototype.stats(),
			);
			await context.close();
			context = await launch();
			const reopened = await pageIn(context);
			await reopened.evaluate(
				(options) => workingTreePrototype.open(options),
				options,
			);
			const recovered = await reopened.evaluate(() =>
				workingTreePrototype.values(),
			);
			check(
				JSON.stringify(recovered) === JSON.stringify(final),
				'Profile reopen lost data',
			);
			// Two retirements cross this threshold; one does not. The budget must survive reopen.
			await reopened.evaluate(() =>
				workingTreePrototype.edit(1, false, 'a', 3000),
			);
			const budgetSaved = await reopened.evaluate(() =>
				workingTreePrototype.stats(),
			);
			await context.close();
			context = await launch();
			const thresholdPage = await pageIn(context);
			await thresholdPage.evaluate(
				(options) =>
					workingTreePrototype.open({
						...options,
						fixture: { ...options.fixture, threshold: 128 * 1024 },
					}),
				options,
			);
			const resumed = await thresholdPage.evaluate(() =>
				workingTreePrototype.edit(1, false, 'a', 4000),
			);
			check(
				'retiredBytes' in budgetSaved.state &&
					typeof budgetSaved.state.retiredBytes === 'number',
				'Missing collection budget',
			);
			check(
				resumed[0]!.gc !== null && budgetSaved.state.retiredBytes > 0,
				'Collection budget did not survive reopen',
			);
			checks.push({
				browser,
				race: {
					a: summary(a.map((sample) => sample.ms)),
					b: summary(b.map((sample) => sample.ms)),
					retries: [...a, ...b].reduce(
						(sum, sample) => sum + sample.retries,
						0,
					),
					collections,
					beforeAck,
					beforeReopen,
					final,
				},
				reopened: recovered,
				durableBudgetBeforeReopen: budgetSaved.state.retiredBytes,
				collectionAfterReopen: resumed[0]!.gc,
			});
			console.log(
				`${browser}: two-tab saves/collection, three retained roots, acknowledgement and full-profile reopen passed`,
			);
		} finally {
			await context.close();
			await rm(profile, { recursive: true, force: true });
		}
	}
	const report = {
		recordedAt: new Date().toISOString(),
		bundleSha256: new Bun.CryptoHasher('sha256').update(script).digest('hex'),
		host: {
			platform: process.platform,
			arch: process.arch,
			bun: Bun.version,
			cpu: cpus()[0]?.model,
		},
		scope:
			'Disposable W-tree IndexedDB prototype vs production overlay; desktop headless browsers, strict transactions, offline back-to-back saves. No phone, quota, forced-kill, network or migration proof.',
		trials,
		saves,
		results,
		checks,
	};
	if (values.output !== undefined) {
		const rawOutput = `${values.output.replace(/\.json$/, '')}.samples.json.gz`;
		await Bun.write(rawOutput, Bun.gzipSync(JSON.stringify(report)));
		await Bun.write(
			values.output,
			`${JSON.stringify(
				{
					...report,
					rawSamplesFile: basename(rawOutput),
					results: report.results.map((entry) => ({
						...entry,
						samples: undefined,
						readBefore: undefined,
						readAfter: undefined,
						lists: undefined,
					})),
				},
				null,
				2,
			)}\n`,
		);
	} else console.log(JSON.stringify(report, null, 2));
} finally {
	server.stop(true);
}
