/**
 * Throwaway W-tree experiment, not a Folder implementation or migration.
 * Scratch IndexedDB only. Does hashing each save plus atomic collection beat
 * overlay capture, without introducing reference counts or a persistent index?
 */
import {
	changeSnapshot,
	readSnapshot,
} from '../../src/browser/git/snapshot.js';
import {
	type GitObject,
	hashObject,
	readCommit,
	readTree,
	writeCommit,
} from '../../src/git/raw-objects.js';
import {
	pathProblem,
	readablePath,
	writableExistingPath,
} from '../../src/paths.js';
import {
	type FileContent,
	merge,
	sameContent,
} from '../../src/shared/merge.js';

type State = {
	workingTree: string | null;
	remoteBase: string | null | undefined;
	pendingCommit: string | null;
	revision: number;
	// Upper bound on bytes retired, not an exact count of unreachable bytes.
	retiredBytes: number;
	collections: number;
};

const initial = (): State => ({
	workingTree: null,
	remoteBase: undefined,
	pendingCommit: null,
	revision: 0,
	retiredBytes: 0,
	collections: 0,
});
const author = {
	name: 'Prototype',
	email: 'prototype@example.invalid',
	timestamp: 1,
};
const request = <T>(input: IDBRequest<T>) =>
	new Promise<T>((resolve, reject) => {
		input.onsuccess = () => resolve(input.result);
		input.onerror = () => reject(input.error);
	});

// Match the production admission check, including its existing-path fast path.
function caseTwin(path: string, paths: ReadonlySet<string>) {
	if (paths.has(path)) return undefined;
	const parts = path.split('/');
	for (const existing of paths) {
		const other = existing.split('/');
		for (let index = 0; index < Math.min(parts.length, other.length); index++) {
			if (parts[index]!.toLowerCase() !== other[index]!.toLowerCase()) break;
			if (parts[index] !== other[index])
				return other.slice(0, index + 1).join('/');
		}
	}
	return undefined;
}

export async function openWorkingTree(
	name: string,
	threshold: number,
	keyGc = false,
) {
	const opening = indexedDB.open(name, 1);
	opening.onupgradeneeded = () => {
		opening.result.createObjectStore('meta');
		const objects = opening.result.createObjectStore('objects');
		if (keyGc) objects.createIndex('type', 'type');
	};
	const database = await request(opening);
	database.onversionchange = () => database.close();

	async function transact<T>(
		mode: IDBTransactionMode,
		work: (transaction: IDBTransaction) => Promise<T>,
	) {
		const transaction = database.transaction(
			['meta', 'objects'],
			mode,
			mode === 'readwrite' ? { durability: 'strict' } : undefined,
		);
		const completed = new Promise<void>((resolve, reject) => {
			transaction.oncomplete = () => resolve();
			transaction.onabort = () => reject(transaction.error);
		});
		completed.catch(() => {});
		try {
			const value = await work(transaction);
			await completed;
			return value;
		} catch (cause) {
			try {
				transaction.abort();
			} catch {
				/* Already aborted. */
			}
			await completed.catch(() => {});
			throw cause;
		}
	}
	const stateIn = async (transaction: IDBTransaction): Promise<State> =>
		(await request(transaction.objectStore('meta').get('state'))) ?? initial();

	async function capture(path?: string) {
		return transact('readonly', async (transaction) => {
			const state = await stateIn(transaction);
			const objects = new Map<string, GitObject>();
			const read = async (oid: string) => {
				const object: GitObject =
					objects.get(oid) ??
					(await request(transaction.objectStore('objects').get(oid)));
				if (object === undefined)
					throw new Error(`Missing prototype object ${oid}`);
				objects.set(oid, object);
				return object;
			};
			// Reuse the production walker without changing its commit-based entry.
			// This wrapper exists only in memory; local saves persist no commits.
			const head = await readSnapshot(
				state.workingTree === null ? null : 'prototype-working-tree',
				async (oid) =>
					oid === 'prototype-working-tree'
						? {
								type: 'commit',
								bytes: writeCommit({
									tree: state.workingTree!,
									parents: [],
									author,
									message: 'Read wrapper',
								}),
							}
						: read(oid),
				path === undefined
					? undefined
					: (directory) => path.startsWith(`${directory}/`),
			);
			const entry = path === undefined ? undefined : head.files.get(path);
			const content =
				entry === undefined || entry.mode === '160000'
					? null
					: (await read(entry.oid)).bytes;
			return { state, head, objects, content };
		});
	}

	async function collect(force = true) {
		const start = performance.now();
		const result = await transact('readwrite', async (transaction) => {
			const state = await stateIn(transaction);
			if (!force && state.retiredBytes < threshold) return null;
			const store = transaction.objectStore('objects');
			// The database maintains this index with the original object record.
			// It proves blob presence/type without transferring opaque blob bytes.
			const blobs = keyGc
				? new Set(await request(store.index('type').getAllKeys('blob')))
				: null;
			let readObjects = 0;
			let readBytes = 0;
			const live = new Set<string>();
			const pending = [state.remoteBase, state.pendingCommit]
				.filter((oid): oid is string => typeof oid === 'string')
				.map((oid) => ({ oid, type: 'commit' as GitObject['type'] }));
			if (state.workingTree !== null)
				pending.push({ oid: state.workingTree, type: 'tree' });
			while (pending.length > 0) {
				const { oid, type } = pending.pop()!;
				if (live.has(oid)) continue;
				if (type === 'blob' && blobs !== null) {
					if (!blobs.has(oid))
						throw new Error(`Incomplete prototype blob: ${oid}`);
					live.add(oid);
					continue;
				}
				const object: GitObject | undefined = await request(store.get(oid));
				if (object?.type !== type)
					throw new Error(`Incomplete prototype closure: ${oid}`);
				live.add(oid);
				readObjects++;
				readBytes += object.bytes.byteLength;
				if (type === 'commit')
					pending.push({ oid: readCommit(object.bytes).tree, type: 'tree' });
				if (type === 'tree')
					for (const entry of readTree(object.bytes)) {
						if (entry.mode !== '160000')
							pending.push({
								oid: entry.oid,
								type:
									entry.mode === '40000' || entry.mode === '040000'
										? 'tree'
										: 'blob',
							});
					}
			}
			let removed = 0;
			for (const key of await request(store.getAllKeys())) {
				if (!live.has(String(key))) {
					store.delete(key);
					removed++;
				}
			}
			transaction
				.objectStore('meta')
				.put(
					{ ...state, retiredBytes: 0, collections: state.collections + 1 },
					'state',
				);
			return {
				removed,
				live: live.size,
				revision: state.revision,
				readObjects,
				readBytes,
			};
		});
		return result === null
			? null
			: { ...result, ms: performance.now() - start };
	}

	return {
		capture,
		collect,
		async seed(files: Map<string, FileContent>) {
			const candidate = await changeSnapshot({
				root: null,
				edits: files,
				read: async () => {
					throw new Error('Fresh seed');
				},
			});
			await transact('readwrite', async (transaction) => {
				for (const [oid, object] of candidate.objects)
					transaction.objectStore('objects').put(object, oid);
				transaction
					.objectStore('meta')
					.put({ ...initial(), workingTree: candidate.tree }, 'state');
			});
		},
		async read(path: string) {
			return (await capture(path)).content;
		},
		async list(prefix: string) {
			return [...(await capture()).head.files.keys()]
				.filter((path) => path.startsWith(prefix))
				.sort();
		},
		async save(
			path: string,
			from: FileContent | null,
			change: FileContent | null,
		) {
			const start = performance.now();
			from = from instanceof Uint8Array ? from.slice() : from;
			change = change instanceof Uint8Array ? change.slice() : change;
			const validPath = readablePath(path) && pathProblem(path) === undefined;
			if (!validPath && (from === null || !writableExistingPath(path)))
				throw new Error('Invalid path');
			if (
				typeof change === 'string' &&
				(change.includes('\0') || !change.isWellFormed())
			)
				throw new Error('Not text');
			let retries = 0;
			const phases = { captureMs: 0, mergeMs: 0, buildMs: 0, publishMs: 0 };
			for (;;) {
				let tick = performance.now();
				const snapshot = await capture(path);
				phases.captureMs += performance.now() - tick;
				const paths = new Set(snapshot.head.files.keys());
				if (!validPath && !paths.has(path))
					throw new Error('Invalid existing path');
				if (change !== null) {
					if (snapshot.head.directories.has(path))
						throw new Error('Occupied directory');
					if (
						caseTwin(
							path,
							new Set([...paths, ...snapshot.head.directories]),
						) !== undefined
					)
						throw new Error('Case twin');
					for (
						let end = path.lastIndexOf('/');
						end > 0;
						end = path.lastIndexOf('/', end - 1)
					)
						if (paths.has(path.slice(0, end)))
							throw new Error('Occupied ancestor');
				}
				tick = performance.now();
				const merged = await merge(path, {
					base: from,
					current: snapshot.content,
					change,
				});
				phases.mergeMs += performance.now() - tick;
				if (sameContent(merged.content, snapshot.content))
					return {
						ms: performance.now() - start,
						retries,
						gc: null,
						phases,
						writtenBytes: 0,
					};
				tick = performance.now();
				const candidate = await changeSnapshot({
					root: snapshot.state.workingTree,
					edits: new Map([[path, merged.content]]),
					read: async (oid) => snapshot.objects.get(oid)!,
				});
				phases.buildMs += performance.now() - tick;
				const retired = [...snapshot.objects.values()].reduce(
					(sum, object) => sum + object.bytes.byteLength,
					0,
				);
				const writtenBytes = [...candidate.objects.values()].reduce(
					(sum, object) => sum + object.bytes.byteLength,
					0,
				);
				tick = performance.now();
				const budget = await transact('readwrite', async (transaction) => {
					const state = await stateIn(transaction);
					if (state.revision !== snapshot.state.revision) return null;
					for (const [oid, object] of candidate.objects)
						transaction.objectStore('objects').put(object, oid);
					const retiredBytes = state.retiredBytes + retired;
					transaction.objectStore('meta').put(
						{
							...state,
							workingTree: candidate.tree,
							revision: state.revision + 1,
							retiredBytes,
						},
						'state',
					);
					return retiredBytes;
				});
				phases.publishMs += performance.now() - tick;
				if (budget === null) {
					retries++;
					continue;
				}
				const gc = budget >= threshold ? await collect(false) : null;
				return {
					ms: performance.now() - start,
					retries,
					gc,
					phases,
					writtenBytes,
				};
			}
		},
		async checkpoint(kind: 'received' | 'sending') {
			const snapshot = await capture();
			if (snapshot.state.workingTree === null) throw new Error('No tree');
			const commit: GitObject = {
				type: 'commit',
				bytes: writeCommit({
					tree: snapshot.state.workingTree,
					parents: snapshot.state.remoteBase ? [snapshot.state.remoteBase] : [],
					author,
					message: `Prototype ${kind}`,
				}),
			};
			const oid = await hashObject(commit);
			await transact('readwrite', async (transaction) => {
				const state = await stateIn(transaction);
				if (state.revision !== snapshot.state.revision)
					throw new Error('Checkpoint raced');
				transaction.objectStore('objects').put(commit, oid);
				transaction.objectStore('meta').put(
					{
						...state,
						[kind === 'received' ? 'remoteBase' : 'pendingCommit']: oid,
						revision: state.revision + 1,
					},
					'state',
				);
			});
			return oid;
		},
		async acknowledge(base: string, pending: string) {
			return transact('readwrite', async (transaction) => {
				const state = await stateIn(transaction);
				if (state.remoteBase !== base || state.pendingCommit !== pending)
					return false;
				transaction.objectStore('meta').put(
					{
						...state,
						remoteBase: pending,
						pendingCommit: null,
						revision: state.revision + 1,
					},
					'state',
				);
				return true;
			});
		},
		async stats() {
			return transact('readonly', async (transaction) => {
				const state = await stateIn(transaction);
				const objects: GitObject[] = await request(
					transaction.objectStore('objects').getAll(),
				);
				return {
					state,
					objects: objects.length,
					bytes: objects.reduce(
						(sum, object) => sum + object.bytes.byteLength,
						0,
					),
				};
			});
		},
		close() {
			database.close();
		},
	};
}
