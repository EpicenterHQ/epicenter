# Working-tree storage experiment

This disposable prototype asks whether storing the current folder as an
immutable tree remains simpler once saves must hash objects and offline editing
must collect garbage. It does not replace the browser engine or implement the
complete public Folder contract.

The [recorded measurements](../../evidence/browser-engine/working-tree-prototype/RESULTS.md)
explain the model, tradeoffs, browser results, and remaining gates. The runner
compares production overlay storage, a working tree with value-reading
collection, and a working tree with an IndexedDB-maintained type index.

From the repository root, with Bun and Playwright browser binaries available:

```sh
bun packages/folder/smoke/working-tree-prototype/run.ts \
  --output packages/folder/evidence/browser-engine/working-tree-prototype/results.json
```

Use `--browser chromium --trials 1 --saves 120` for a narrower run. Output contains
per-case summaries and a compressed companion with every raw sample. Browser
profiles are temporary and removed afterward; scratch databases are named
`PROTOTYPE-wipe-me-*`. No app profile or saved app data is opened.

`store.ts` owns the scratch database and working-tree publication. `client.ts`
uses the same fixtures against the prototype and current engine. `run.ts` owns
fresh browser profiles, timing, concurrent saves, and reopening checks.

This remains an experiment pending the phone, quota, migration, and equivalence
checks in the report. Delete the prototype after the keep-or-replace decision;
keep the measurement evidence. Do not export it or add its variants to app flows.
