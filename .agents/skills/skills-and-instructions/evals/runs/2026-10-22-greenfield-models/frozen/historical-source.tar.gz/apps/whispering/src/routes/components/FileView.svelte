<!--
	A file opened beside the recordings. A transcript that reads shows its
	body, edited as a row. Any other text file, and a row file shown as text,
	shows its exact editable text. The folder retains input and autosaves
	after a pause, even after this view leaves, one write at a time for this file.
-->
<script lang="ts">
	import { getWhispering } from '$lib/whispering.svelte.js';
	import { textRead } from '$lib/file-reads.js';
	import { getFolder } from '$lib/folder.js';

	import { Badge } from '@epicenter/ui/badge';
	import { Button } from '@epicenter/ui/button';
	import * as Empty from '@epicenter/ui/empty';
	import { Loading } from '@epicenter/ui/loading';
	import ArrowLeftIcon from '@lucide/svelte/icons/arrow-left';
	import AudioLinesIcon from '@lucide/svelte/icons/audio-lines';
	import CopyIcon from '@lucide/svelte/icons/copy';
	import FileIcon from '@lucide/svelte/icons/file';
	import TriangleAlertIcon from '@lucide/svelte/icons/triangle-alert';
	import { basename, dirname, withFileNewlines } from '@epicenter/folder/file-browser';
	import { toast } from '@epicenter/ui/sonner';
	import { createQuery } from '@tanstack/svelte-query';
	import { audioMimeTypeOf } from '$lib/audio-format.js';
	import { TRANSCRIPTIONS } from '$lib/definition.js';
	import { type Whispering, rowTableOf } from '$lib/whispering.svelte.js';
	import AudioPlayer from './AudioPlayer.svelte';
	import { confirmDelete, copyPath, lf } from './file-actions.js';
	import FileNameBar from './FileNameBar.svelte';
	import SaveStatus from './SaveStatus.svelte';
	import { Textarea } from '@epicenter/ui/textarea';

	let {
		path,
		onBack,
	}: {
		/** The file shown. The parent keys this view by it. */
		path: string;
		/** Shown on narrow windows, where the list and the editor take turns. */
		onBack?: () => void;
	} = $props();
	const whispering = getWhispering();

	// The parent keys this view by the file; what is typed is sent to that one.
	// svelte-ignore state_referenced_locally
	const own = path;
	const table = $derived(rowTableOf(path));
	const audio = $derived(table === undefined && audioMimeTypeOf(path) !== undefined);
	const asText = $derived(!audio && whispering.showsText(path));
	/**
	 * One file edit supplies the transcript body, whole text and diagnostics.
	 */
	// svelte-ignore state_referenced_locally
	const fileEdit = whispering.edit(own);
	const { queries } = getFolder();
	/** What the file is while it shows as text; its reads keep the text edit current. */
	const opened = createQuery(() => ({ ...queries.file(path, textRead), enabled: asText }));
	/** A transcript that reads: its body is edited here, its fields kept. */
	const transcript = $derived.by(() => {
		if (table !== TRANSCRIPTIONS || asText) return undefined;
		const shown = fileEdit.markdown;
		return shown?.issues === null ? shown : undefined;
	});
	// Save metadata stays passive until this view actually demands text.
	const buffer = $derived(
		(!audio && !asText) || opened.data?.kind === 'text' || whispering.isSaving(path) || whispering.isUnsaved(path)
			? fileEdit.buffer : undefined,
	);
	const unsaved = $derived(buffer?.status === 'ready' ? buffer.unsaved : undefined);
	/** The file's text as typed while an edit is unsaved, else as stored. */
	const text = $derived(
		buffer?.status === 'ready' && (buffer.unsaved !== undefined || opened.data?.kind === 'text') ? buffer.text : undefined,
	);
	/** Why the current source does not read as a row, including unsaved input. */
	const issues = $derived(
		table === undefined || text === undefined ? undefined : (fileEdit.markdown?.issues ?? undefined),
	);

	function show(source: boolean) {
		const problem = source ? whispering.editSource(path) : whispering.useForm(path);
		if (problem)
			toast.error(source ? 'The text was not opened for editing' : 'The text was not opened alone', {
				description: problem,
			});
	}

	const name = $derived(basename(path));
	const directory = $derived(dirname(path));
	/** The recording whose row names this file as its audio, if one does. */
	const owner = $derived(whispering.recordingNaming(path));

	/** A file shown as details: its extension names the type, then its size when it is known. */
	function details(size?: number) {
		const dot = name.lastIndexOf('.');
		const kind = dot > 0 ? `${name.slice(dot + 1).toUpperCase()} file` : 'File';
		if (size === undefined) return kind;
		if (size < 1024) return `${kind} · ${size} ${size === 1 ? 'byte' : 'bytes'}`;
		if (size < 1024 * 1024) return `${kind} · ${(size / 1024).toFixed(1)} KB`;
		return `${kind} · ${(size / (1024 * 1024)).toFixed(1)} MB`;
	}
</script>

<section class="flex h-full min-h-0 flex-col" aria-label="File">
	<div class="flex items-center gap-2 border-b px-3 py-3 sm:px-4">
		{#if onBack}
			<Button variant="ghost" size="icon-sm" aria-label="Back to recordings" onclick={onBack} {@attach (node: HTMLElement) => node.focus()}>
				<ArrowLeftIcon />
			</Button>
		{/if}
		{#if audio}
			<AudioLinesIcon class="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
		{:else}
			<FileIcon class="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
		{/if}
		<div class="min-w-0 flex-1">
			<h2 class="truncate text-sm font-medium">{name}</h2>
			<p class="truncate font-mono text-xs text-muted-foreground">{path}</p>
		</div>
		<Button variant="ghost" size="icon-sm" tooltip="Copy path" aria-label="Copy path" onclick={() => void copyPath(path)}>
			<CopyIcon />
		</Button>
	</div>

	{#if buffer?.error && buffer?.error.name !== 'SourceUnavailable'}
		<p role="alert" class="border-b px-4 py-2 text-sm text-destructive">{buffer?.error.message}</p>
	{/if}

	{#if unsaved !== undefined && buffer?.error?.name === 'SourceUnavailable' && (asText ? text !== undefined : transcript !== undefined)}
		<div class="space-y-2 p-4" role="status">
			<p>The saved file changed. Your draft remains available.</p>
			<Textarea readonly aria-label="Unsaved file changes" value={fileEdit.text} class="min-h-40 font-mono text-xs" />
		</div>
	{/if}
	{#if (asText ? text === undefined : transcript === undefined) && unsaved !== undefined}
		<SaveStatus {path} class="shrink-0 border-b px-4 py-1" />
		<div class="space-y-2 p-4" role="status">
			<p>The saved file no longer reads. Your unsaved changes are kept below.</p>
			<Textarea readonly aria-label="Unsaved file changes" value={fileEdit.text} class="min-h-40 font-mono text-xs" />
		</div>
	{:else if audio}
		<div class="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto px-3 py-4 sm:px-4" data-testid="audio-file-view">
			<AudioPlayer {path} label="Audio in {name}" />
			<dl class="grid grid-cols-[7rem_1fr] gap-x-3 gap-y-1.5 text-sm">
				<dt class="text-muted-foreground">Type</dt>
				<dd>{details()} · {audioMimeTypeOf(path)}</dd>
				<dt class="text-muted-foreground">Recording</dt>
				<dd>
					{#if owner}
						<Button variant="link" class="h-auto p-0" onclick={() => whispering.open(owner.path)}>
							{owner.row.fields.title || owner.path}
						</Button>
					{:else}
						No recording row names this file.
					{/if}
				</dd>
			</dl>
		</div>
	{:else if transcript}
		{@const row = transcript}
		<SaveStatus {path} class="shrink-0 border-b px-4 py-1" />
		<div class="flex min-h-0 flex-1 flex-col gap-2 px-3 py-3 sm:px-4">
			<p class="text-xs text-muted-foreground">
				The transcript’s text, the body of its file. Its fields are kept as they are.
				<Button size="xs" variant="outline" class="ml-1" onclick={() => void show(true)}>Edit the whole file</Button>
			</p>
			<Textarea
				class="min-h-40 flex-1 resize-none font-sans"
				bind:value={
					() => row.body,
					(value) => fileEdit.change({ body: value })
				}
				disabled={fileEdit.locked}
				aria-label="Contents of {name}"
			/>
		</div>
	{:else if !asText}
		<Empty.Root class="flex-1">
			<Empty.Title>{name} is no longer in the folder</Empty.Title>
			<Empty.Description>It was renamed or deleted, here or by another program.</Empty.Description>
		</Empty.Root>
	{:else if text !== undefined}
		{@const shown = text}
		<SaveStatus {path} class="shrink-0 border-b px-4 py-1" />
		{#if issues}
			<div class="shrink-0 border-b bg-destructive/5 px-4 py-2 text-xs" role="status" data-testid="needs-repair">
				<p class="mb-1 flex flex-wrap items-center gap-2 font-medium">
					<Badge variant="destructive">Needs repair</Badge>
					This file does not read as a row yet. Fix it here; it saves when you pause.
				</p>
				<ul class="space-y-0.5 text-muted-foreground">
					{#each issues as issue, index (index)}
						<li>{issue.line === undefined ? '' : `Line ${issue.line}: `}{issue.message}</li>
					{/each}
				</ul>
			</div>
		{:else if table === TRANSCRIPTIONS}
			<p class="shrink-0 px-4 pt-2 text-xs text-muted-foreground">
				The whole file, as its text. It saves as typed.
				<Button size="xs" variant="outline" class="ml-1" onclick={() => void show(false)}>Edit the text only</Button>
			</p>
		{/if}
		<div class="flex min-h-0 flex-1 flex-col gap-2 px-3 py-3 sm:px-4">
			<Textarea
				class="min-h-40 flex-1 resize-none font-mono text-xs"
				bind:value={() => lf(shown), (value) => fileEdit.replaceText(withFileNewlines(value, shown))}
				{@attach () => { whispering.editSource(path); }}
				disabled={fileEdit.locked}
				aria-label="Contents of {name}"
				spellcheck={false}
			/>
		</div>
	{:else if opened.data?.kind === 'binary' || opened.data?.kind === 'tooLarge'}
		<Empty.Root class="flex-1">
			<Empty.Media><FileIcon class="size-8 text-muted-foreground" /></Empty.Media>
			<Empty.Title>{details(opened.data.size)}</Empty.Title>
			<Empty.Description>
				{opened.data.kind === 'binary'
					? 'This file is not text, so it is listed here but not opened for editing.'
					: 'This text file is larger than 1 MB, so it is not opened in the editor.'}
				Rename and delete still work on it.
			</Empty.Description>
		</Empty.Root>
	{:else if opened.isError}
		<Empty.Root class="flex-1">
			<Empty.Media><TriangleAlertIcon class="size-8 text-muted-foreground" /></Empty.Media>
			<Empty.Title>Could not open this file</Empty.Title>
			<Empty.Description>{opened.error.message}</Empty.Description>
			<Button variant="outline" size="sm" onclick={() => void opened.refetch()}>Try again</Button>
		</Empty.Root>
	{:else}
		<Loading class="flex-1" label="Opening {name}…" />
	{/if}

	<FileNameBar
		prefix={directory === '' ? '' : `${directory}/`}
		{name}
		onRename={(next) => whispering.rename(path, next)}
		onDelete={() => void confirmDelete(whispering, path)}
	/>
</section>
